import { EventCategory, PaymentSettings, Booking, HeroCoverSettings, CreatorApplication } from '../types';

export const INITIAL_CATEGORIES: EventCategory[] = [
  {
    id: 'marriage',
    name: 'Marriage Events',
    slug: 'marriage-events',
    tagline: 'Emotional Haldi, Sangeet, Varmala & Reception cinematic 4K vertical reels',
    description: 'Capture tears, laughter, and high-energy dance performances in Apple ProRes 4K HDR. Color graded with trending audio and delivered to your phone in 24 hours.',
    coverImage: '/src/assets/images/marriage_reel_event_1791705584070.jpg',
    iconName: 'HeartHandshake',
    basePrice: 11999,
    packages: [
      {
        id: 'pkg-marriage-basic',
        name: 'Haldi & Mehendi Spotlight',
        price: 8999,
        reelsCount: 2,
        durationHours: 3,
        turnaroundHours: 24,
        features: [
          '2 High-Energy Edited Reels (4K 60fps)',
          'Shot on iPhone 16 Pro Max + DJI Gimbal',
          'Cinematic Color Grade & Trending Audio',
          'Instant AirDrop of raw favorite clips',
          'Turnaround within 24 hours'
        ]
      },
      {
        id: 'pkg-marriage-pro',
        name: 'Wedding & Varmala Signature',
        price: 14999,
        reelsCount: 4,
        durationHours: 6,
        turnaroundHours: 18,
        popular: true,
        features: [
          '4 Cinematic Masterpiece Reels (Varmala, Pheras, Emotions)',
          'iPhone 16 Pro Max + Rode Wireless PRO Audio Mics',
          'Motorized Gimbal + Cinematic Low-Light Setup',
          'Same-Day Teaser Reel (within 6 hours)',
          'All Raw 4K B-Roll footage in cloud drive',
          'Direct Instagram Collab & Tags'
        ]
      },
      {
        id: 'pkg-marriage-grand',
        name: 'Full Day Royal Storyteller',
        price: 24999,
        reelsCount: 7,
        durationHours: 10,
        turnaroundHours: 12,
        features: [
          '7 Ultra-Cinematic Reels covering entire wedding story',
          'Dual iPhone 16 Pro setup with continuous coverage',
          'Express 12-Hour turnaround for viral sharing',
          'Dedicated creator attached to bride & groom',
          'Raw ProRes footage archive + Story clips',
          'Custom font and aesthetic color grading'
        ]
      }
    ]
  },
  {
    id: 'car-bike-delivery',
    name: 'Car & Bike Delivery',
    slug: 'car-bike-delivery',
    tagline: 'Showroom reveal ceremony, key handover & high-octane exhaust sound reels',
    description: 'Turn your dream vehicle delivery into an unforgettable cinematic reveal. From the silk cover unveil and ribbon cutting to the first drive with engine rumble audio.',
    coverImage: '/src/assets/images/vehicle_delivery_event_1791705596887.jpg',
    iconName: 'Car',
    basePrice: 5999,
    packages: [
      {
        id: 'pkg-delivery-essential',
        name: 'Showroom Reveal Quick-Cut',
        price: 4999,
        reelsCount: 1,
        durationHours: 1.5,
        turnaroundHours: 12,
        features: [
          '1 Fast-Paced Viral Reveal Reel (30-45 sec)',
          'Silk Cover Drop & Key Handover focus',
          'Crisp Exhaust sound with wireless audio mic',
          'Delivered same-night for immediate posting',
          '100% Raw camera roll clips delivered'
        ]
      },
      {
        id: 'pkg-delivery-cinema',
        name: 'Supercar & Superbike Cinema',
        price: 7999,
        reelsCount: 3,
        durationHours: 3,
        turnaroundHours: 12,
        popular: true,
        features: [
          '3 Stylized Reels: Unveil, Walkaround & First Drive',
          'Dynamic Rolling shots & low-angle wheel motion',
          'Crisp Cold-Start & revving engine sound design',
          'Speed-ramping & beat-synced editing',
          'Express 12-Hour final delivery'
        ]
      },
      {
        id: 'pkg-delivery-epic',
        name: 'Sunset Cruise & Delivery Docu',
        price: 11999,
        reelsCount: 5,
        durationHours: 5,
        turnaroundHours: 8,
        features: [
          '5 Comprehensive Reels: Delivery + Golden Hour City Cruise',
          'Interior ambient cockpit details & ambient lighting',
          'Pro-grade color grading for paint finish gloss',
          'Express 8-Hour turnaround',
          'Instagram Collaborative Post setup'
        ]
      }
    ]
  },
  {
    id: 'parties-nightlife',
    name: 'Birthdays & Nightlife',
    slug: 'birthdays-nightlife',
    tagline: 'Sparkler celebrations, club nights, DJ drops and milestone birthdays',
    description: 'High-energy vertical reels that make your party look legendary. Shot with dynamic camera motion, RGB pocket rim lights, and bass-heavy audio sync.',
    coverImage: '/src/assets/images/party_event_reel_1791705607944.jpg',
    iconName: 'PartyPopper',
    basePrice: 6999,
    packages: [
      {
        id: 'pkg-party-vibe',
        name: 'Party Highlight Reel',
        price: 5499,
        reelsCount: 2,
        durationHours: 2.5,
        turnaroundHours: 24,
        features: [
          '2 Viral Vertical Reels with music beat sync',
          'Cake Cutting, Sparkler blast & Toast moments',
          'Pocket RGB LED lighting for dim venues',
          'Delivered in 24 hours'
        ]
      },
      {
        id: 'pkg-party-afterdark',
        name: 'VIP Club & DJ Special',
        price: 8999,
        reelsCount: 4,
        durationHours: 4,
        turnaroundHours: 12,
        popular: true,
        features: [
          '4 High-Octane Reels with hype transitions',
          'Crowd reactions, DJ booth & Champagne spray',
          'Wireless audio recorder for clean music track mix',
          'Express 12-Hour delivery before brunch next morning'
        ]
      }
    ]
  }
];

export const INITIAL_PAYMENT_SETTINGS: PaymentSettings = {
  upiId: 'iphonecreator.pay@okhdfcbank',
  payeeName: 'ReelMate Creator Studio',
  qrCodeType: 'dynamic',
  paymentNote: 'Scan the QR code via GPay, PhonePe, Paytm, or BHIM. Pay 30% advance deposit to lock creator date & slot.',
  advancePercentage: 30,
  supportPhone: '+91 98765 43210',
  currencySymbol: '₹',
  adminPin: '2026',
  hideAdminButtonFromPublic: true,
};

export const INITIAL_BOOKINGS: Booking[] = [
  {
    id: 'REEL-84192',
    categoryId: 'marriage',
    categoryName: 'Marriage Events',
    packageId: 'pkg-marriage-pro',
    packageName: 'Wedding & Varmala Signature',
    eventDate: '2026-11-04',
    startTime: '17:30',
    durationHours: 6,
    clientName: 'Rohan & Ananya Sharma',
    clientPhone: '+91 98450 11223',
    clientEmail: 'rohan.sharma@example.com',
    instagramHandle: '@ananya_and_rohan',
    venueLocation: 'The Grand Leela Palace, Bengaluru',
    musicAestheticVibe: 'Bollywood Acoustic & Soft Cinematic Slow-mo',
    specialInstructions: 'Focus on bride entry with floral umbrella and grand varmala fireworks.',
    totalPrice: 14999,
    advancePaid: 4500,
    paymentMode: 'ADVANCE',
    paymentStatus: 'VERIFIED',
    transactionId: 'UPI-HDFC-9923847192',
    createdAt: '2026-10-10T14:20:00.000Z',
    deliverablesStatus: 'NOT_STARTED'
  },
  {
    id: 'REEL-93821',
    categoryId: 'car-bike-delivery',
    categoryName: 'Car & Bike Delivery',
    packageId: 'pkg-delivery-cinema',
    packageName: 'Supercar & Superbike Cinema',
    eventDate: '2026-10-18',
    startTime: '11:00',
    durationHours: 3,
    clientName: 'Vikramaditya Roy',
    clientPhone: '+91 99100 44556',
    clientEmail: 'vikram.roy@example.com',
    instagramHandle: '@vikram_speed',
    venueLocation: 'Ducati Showroom, Indiranagar',
    musicAestheticVibe: 'Fast Speed-ramping & Heavy Synthwave',
    specialInstructions: 'Capture first cold start revving and satin red cover reveal.',
    totalPrice: 7999,
    advancePaid: 2400,
    paymentMode: 'ADVANCE',
    paymentStatus: 'PENDING_VERIFICATION',
    transactionId: 'UTR429188402918',
    createdAt: '2026-10-11T00:15:00.000Z',
    deliverablesStatus: 'NOT_STARTED'
  }
];

export const INITIAL_HERO_SETTINGS: HeroCoverSettings = {
  coverImage: '/src/assets/images/hero_reel_creator_1791705571989.jpg',
  badgeText: 'Cinematic Mobile Videography On Demand',
  headline: 'Book an iPhone Reel Creator for Marriage & Delivery Events',
  subheadline: 'Don’t let your wedding emotions or showroom car and bike delivery vanish into boring traditional video edits. Book dedicated iPhone 16 Pro creators with motorized gimbals, crisp wireless audio, and viral 24-hour delivery.',
  primaryCtaText: 'Select Event & Book Date',
  secondaryCtaText: 'Instant UPI & QR Advance Locking',
  cameraSpecBadge: 'iPhone 16 Pro Max · DJI Osmo Gimbal · Rode Wireless Mic',
  statEventsCount: '500+ Events Filmed',
  statRating: '4.9 / 5.0 Rating',
  statTurnaround: 'AirDrop Raw B-Roll Ready',
};

export const INITIAL_CREATOR_APPLICATIONS: CreatorApplication[] = [
  {
    id: 'CREATOR-APP-9102',
    fullName: 'Arjun Verma',
    phone: '+91 98112 33445',
    email: 'arjun.shoots@gmail.com',
    city: 'Bengaluru / Indiranagar',
    instagramHandle: '@arjun.cinematics',
    portfolioUrl: 'https://instagram.com/arjun.cinematics',
    phoneModel: 'iPhone 16 Pro Max',
    phoneStorage: '512GB',
    shootsProResLog: true,
    gimbalModel: 'DJI Osmo Mobile 6',
    micModel: 'Rode Wireless PRO (Dual TX/RX)',
    lightingAndAccessories: 'Ulanzi VL49 RGB light, Freewell Variable ND filters',
    gearPhotoUrl: '/src/assets/images/hero_reel_creator_1791705571989.jpg',
    eventExperience: ['Marriage & Haldi', 'Car & Bike Delivery'],
    expectedRatePerShoot: 5500,
    yearsOfExperience: '2+ years mobile cinematography',
    bioNotes: 'Experienced in slow-motion varmala shots, speed-ramping supercar unveilings, and instant client AirDrop handover.',
    status: 'APPROVED',
    appliedAt: '2026-10-09T10:00:00.000Z'
  },
  {
    id: 'CREATOR-APP-9241',
    fullName: 'Sneha Kulkarni',
    phone: '+91 99203 88123',
    email: 'sneha.reels@gmail.com',
    city: 'Mumbai / Bandra',
    instagramHandle: '@sneha.visuals',
    portfolioUrl: 'https://instagram.com/sneha.visuals',
    phoneModel: 'iPhone 15 Pro Max',
    phoneStorage: '256GB',
    shootsProResLog: true,
    gimbalModel: 'Insta360 Flow Gimbal',
    micModel: 'DJI Mic 2 with Windscreen',
    lightingAndAccessories: 'Aputure Amaran Pocket LED, magnetic anamorphic lens',
    gearPhotoUrl: '/src/assets/images/marriage_reel_event_1791705584070.jpg',
    eventExperience: ['Marriage & Haldi', 'Birthdays & Nightlife'],
    expectedRatePerShoot: 6000,
    yearsOfExperience: '3 years freelance wedding filmmaker',
    bioNotes: 'Specializes in aesthetic couple portraits, emotional mother-daughter hugs, and color grading in DaVinci Resolve.',
    status: 'PENDING',
    appliedAt: '2026-10-11T02:30:00.000Z'
  }
];
