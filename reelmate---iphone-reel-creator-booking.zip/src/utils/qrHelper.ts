import QRCode from 'qrcode';

export async function generateUpiQrDataUrl(
  upiId: string,
  payeeName: string,
  amount: number,
  transactionNote: string = 'Reel Booking Deposit'
): Promise<string> {
  const cleanUpi = upiId.trim();
  const cleanName = payeeName.trim();
  
  // UPI Standard URI syntax
  const upiUri = `upi://pay?pa=${encodeURIComponent(cleanUpi)}&pn=${encodeURIComponent(cleanName)}&am=${amount.toFixed(2)}&cu=INR&tn=${encodeURIComponent(transactionNote)}`;
  
  try {
    const dataUrl = await QRCode.toDataURL(upiUri, {
      width: 320,
      margin: 2,
      color: {
        dark: '#0f172a',
        light: '#ffffff',
      },
      errorCorrectionLevel: 'M',
    });
    return dataUrl;
  } catch (err) {
    console.error('Failed to generate UPI QR code:', err);
    return '';
  }
}

export function formatCurrency(amount: number, symbol: string = '₹'): string {
  return `${symbol}${amount.toLocaleString('en-IN')}`;
}
