import React from 'react';
import { AppProvider } from './context/AppContext';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { CategoryTabsSection } from './components/CategoryTabsSection';
import { GearAndShowcaseSection } from './components/GearAndShowcaseSection';
import { BookingModal } from './components/BookingModal';
import { BookingLookupModal } from './components/BookingLookupModal';
import { BecomeCreatorModal } from './components/BecomeCreatorModal';
import { AdminPortal } from './components/AdminPortal';
import { AdminPinModal } from './components/AdminPinModal';
import { Footer } from './components/Footer';

export default function App() {
  const handleScrollToCategories = () => {
    const el = document.getElementById('categories');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <AppProvider>
      <div className="min-h-screen bg-zinc-950 text-zinc-100 font-sans selection:bg-amber-400 selection:text-zinc-950">
        <Header onScrollToBook={handleScrollToCategories} />
        
        <main>
          <HeroSection onExploreClick={handleScrollToCategories} />
          <CategoryTabsSection />
          <GearAndShowcaseSection />
        </main>

        <Footer />

        {/* Global Modals */}
        <BookingModal />
        <BookingLookupModal />
        <BecomeCreatorModal />
        <AdminPortal />
        <AdminPinModal />
      </div>
    </AppProvider>
  );
}
