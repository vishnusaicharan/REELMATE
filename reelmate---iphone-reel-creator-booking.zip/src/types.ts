export interface Package {
  id: string;
  name: string;
  price: number;
  reelsCount: number;
  durationHours: number;
  turnaroundHours: number;
  features: string[];
  popular?: boolean;
}

export interface EventCategory {
  id: string;
  name: string;
  slug: string;
  tagline: string;
  description: string;
  coverImage: string;
  iconName: string;
  basePrice: number;
  packages: Package[];
  isCustom?: boolean;
}

export interface PaymentSettings {
  upiId: string;
  payeeName: string;
  qrCodeType: 'dynamic' | 'custom_image';
  customQrImageUrl?: string;
  paymentNote: string;
  advancePercentage: number;
  supportPhone: string;
  currencySymbol: string;
  adminPin?: string;
  hideAdminButtonFromPublic?: boolean;
}

export interface Booking {
  id: string;
  categoryId: string;
  categoryName: string;
  packageId: string;
  packageName: string;
  eventDate: string;
  startTime: string;
  durationHours: number;
  clientName: string;
  clientPhone: string;
  clientEmail: string;
  instagramHandle: string;
  venueLocation: string;
  musicAestheticVibe: string;
  specialInstructions: string;
  totalPrice: number;
  advancePaid: number;
  paymentMode: 'FULL' | 'ADVANCE';
  paymentStatus: 'PENDING_VERIFICATION' | 'VERIFIED' | 'COMPLETED' | 'CANCELLED';
  transactionId: string;
  paymentReceiptUrl?: string;
  createdAt: string;
  deliverablesStatus: 'NOT_STARTED' | 'SHOOTING' | 'EDITING' | 'DELIVERED';
  finalDriveLink?: string;
}

export interface HeroCoverSettings {
  coverImage: string;
  badgeText: string;
  headline: string;
  subheadline: string;
  primaryCtaText: string;
  secondaryCtaText: string;
  cameraSpecBadge: string;
  statEventsCount: string;
  statRating: string;
  statTurnaround: string;
}

export interface CreatorApplication {
  id: string;
  fullName: string;
  phone: string;
  email: string;
  city: string;
  instagramHandle: string;
  portfolioUrl?: string;
  phoneModel: string;
  phoneStorage: string;
  secondaryPhone?: string;
  allPhonesList?: string[];
  shootsProResLog: boolean;
  gimbalModel: string;
  micModel: string;
  lightingAndAccessories: string;
  phonePhotoUrl?: string;
  gearPhotoUrl?: string;
  eventExperience: string[];
  expectedRatePerShoot: number;
  yearsOfExperience: string;
  bioNotes?: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  appliedAt: string;
}
