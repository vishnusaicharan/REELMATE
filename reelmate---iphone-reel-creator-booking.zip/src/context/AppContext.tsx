import React, { createContext, useContext, useState, useEffect } from 'react';
import { EventCategory, PaymentSettings, Booking, Package, HeroCoverSettings, CreatorApplication } from '../types';
import { INITIAL_CATEGORIES, INITIAL_PAYMENT_SETTINGS, INITIAL_BOOKINGS, INITIAL_HERO_SETTINGS, INITIAL_CREATOR_APPLICATIONS } from '../data/initialData';

export type AdminTabType = 'COVER' | 'TABS' | 'PRICES' | 'PAYMENTS' | 'BOOKINGS' | 'APPLICATIONS' | 'SECURITY';

interface AppContextType {
  categories: EventCategory[];
  paymentSettings: PaymentSettings;
  bookings: Booking[];
  heroSettings: HeroCoverSettings;
  creatorApplications: CreatorApplication[];
  activeCategoryId: string;
  setActiveCategoryId: (id: string) => void;
  
  // Booking modal
  isBookingModalOpen: boolean;
  selectedCategoryForBooking: EventCategory | null;
  selectedPackageForBooking: Package | null;
  openBookingModal: (category: EventCategory, pkg: Package) => void;
  closeBookingModal: () => void;

  // Become a Creator modal
  isCreatorModalOpen: boolean;
  openCreatorModal: () => void;
  closeCreatorModal: () => void;
  addCreatorApplication: (app: Omit<CreatorApplication, 'id' | 'appliedAt' | 'status'>) => CreatorApplication;
  updateCreatorApplicationStatus: (id: string, status: CreatorApplication['status']) => void;
  deleteCreatorApplication: (id: string) => void;
  
  // Lookup modal
  isLookupModalOpen: boolean;
  openLookupModal: () => void;
  closeLookupModal: () => void;
  
  // Admin authentication & modal
  isAdminAuthenticated: boolean;
  isAdminModalOpen: boolean;
  isAdminPinModalOpen: boolean;
  adminActiveTab: AdminTabType;
  setAdminActiveTab: (tab: AdminTabType) => void;
  requestAdminAccess: (targetTab?: AdminTabType) => void;
  openAdminModal: (targetTab?: AdminTabType) => void;
  closeAdminModal: () => void;
  openAdminPinModal: () => void;
  closeAdminPinModal: () => void;
  verifyAdminPin: (enteredPin: string) => boolean;
  logoutAdmin: () => void;
  
  // Cover page mutations (Admin)
  updateHeroSettings: (updated: Partial<HeroCoverSettings>) => void;
  resetHeroSettings: () => void;

  // Category & Tab mutations (Admin)
  addCategory: (newCategory: Omit<EventCategory, 'id' | 'slug'>) => void;
  updateCategory: (id: string, updated: Partial<EventCategory>) => void;
  deleteCategory: (id: string) => void;
  
  // Package mutations (Admin)
  updatePackage: (categoryId: string, packageId: string, updated: Partial<Package>) => void;
  addPackage: (categoryId: string, newPkg: Omit<Package, 'id'>) => void;
  deletePackage: (categoryId: string, packageId: string) => void;
  
  // Payment settings mutations (Admin)
  updatePaymentSettings: (updated: Partial<PaymentSettings>) => void;
  
  // Bookings mutations
  addBooking: (booking: Omit<Booking, 'id' | 'createdAt' | 'paymentStatus' | 'deliverablesStatus'>) => Booking;
  updateBookingStatus: (id: string, paymentStatus: Booking['paymentStatus'], deliverablesStatus?: Booking['deliverablesStatus']) => void;
  deleteBooking: (id: string) => void;
  resetAllData: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEYS = {
  CATEGORIES: 'reelcraft_categories_v1',
  PAYMENT_SETTINGS: 'reelcraft_payment_settings_v1',
  BOOKINGS: 'reelcraft_bookings_v1',
  HERO_SETTINGS: 'reelcraft_hero_settings_v1',
  CREATOR_APPLICATIONS: 'reelcraft_creator_applications_v1',
  ADMIN_AUTH: 'reelcraft_admin_session_auth_v1',
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load initial state with localStorage fallbacks
  const [categories, setCategories] = useState<EventCategory[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CATEGORIES);
      return saved ? JSON.parse(saved) : INITIAL_CATEGORIES;
    } catch {
      return INITIAL_CATEGORIES;
    }
  });

  const [paymentSettings, setPaymentSettings] = useState<PaymentSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PAYMENT_SETTINGS);
      return saved ? JSON.parse(saved) : INITIAL_PAYMENT_SETTINGS;
    } catch {
      return INITIAL_PAYMENT_SETTINGS;
    }
  });

  const [bookings, setBookings] = useState<Booking[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.BOOKINGS);
      return saved ? JSON.parse(saved) : INITIAL_BOOKINGS;
    } catch {
      return INITIAL_BOOKINGS;
    }
  });

  const [heroSettings, setHeroSettings] = useState<HeroCoverSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.HERO_SETTINGS);
      return saved ? JSON.parse(saved) : INITIAL_HERO_SETTINGS;
    } catch {
      return INITIAL_HERO_SETTINGS;
    }
  });

  const [creatorApplications, setCreatorApplications] = useState<CreatorApplication[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CREATOR_APPLICATIONS);
      return saved ? JSON.parse(saved) : INITIAL_CREATOR_APPLICATIONS;
    } catch {
      return INITIAL_CREATOR_APPLICATIONS;
    }
  });

  const [activeCategoryId, setActiveCategoryId] = useState<string>(() => {
    return categories[0]?.id || 'marriage';
  });

  // Modal states
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
  const [selectedCategoryForBooking, setSelectedCategoryForBooking] = useState<EventCategory | null>(null);
  const [selectedPackageForBooking, setSelectedPackageForBooking] = useState<Package | null>(null);

  const [isCreatorModalOpen, setIsCreatorModalOpen] = useState(false);
  const [isLookupModalOpen, setIsLookupModalOpen] = useState(false);
  
  // Admin auth states
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(() => {
    try {
      return sessionStorage.getItem(STORAGE_KEYS.ADMIN_AUTH) === 'true';
    } catch {
      return false;
    }
  });
  const [isAdminModalOpen, setIsAdminModalOpen] = useState(false);
  const [isAdminPinModalOpen, setIsAdminPinModalOpen] = useState(false);
  const [adminActiveTab, setAdminActiveTab] = useState<AdminTabType>('COVER');

  // Sync with localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(categories));
    } catch (err) {
      console.error('Failed to save categories', err);
    }
  }, [categories]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.PAYMENT_SETTINGS, JSON.stringify(paymentSettings));
    } catch (err) {
      console.error('Failed to save payment settings', err);
    }
  }, [paymentSettings]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.BOOKINGS, JSON.stringify(bookings));
    } catch (err) {
      console.error('Failed to save bookings', err);
    }
  }, [bookings]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.HERO_SETTINGS, JSON.stringify(heroSettings));
    } catch (err) {
      console.error('Failed to save hero settings', err);
    }
  }, [heroSettings]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.CREATOR_APPLICATIONS, JSON.stringify(creatorApplications));
    } catch (err) {
      console.error('Failed to save creator applications', err);
    }
  }, [creatorApplications]);

  // Keep active category valid
  useEffect(() => {
    if (categories.length > 0 && !categories.some(c => c.id === activeCategoryId)) {
      setActiveCategoryId(categories[0].id);
    }
  }, [categories, activeCategoryId]);

  // Listen for secret admin hotkey (Ctrl+Shift+A or Cmd+Shift+A) or URL hash (#admin)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === 'A' || e.key === 'a')) {
        e.preventDefault();
        requestAdminAccess();
      }
    };

    window.addEventListener('keydown', handleKeyDown);

    // Check URL parameters or hash on mount
    if (window.location.hash === '#admin' || window.location.search.includes('admin=1')) {
      requestAdminAccess();
    }

    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isAdminAuthenticated]);

  const openBookingModal = (category: EventCategory, pkg: Package) => {
    setSelectedCategoryForBooking(category);
    setSelectedPackageForBooking(pkg);
    setIsBookingModalOpen(true);
  };

  const closeBookingModal = () => {
    setIsBookingModalOpen(false);
    setSelectedCategoryForBooking(null);
    setSelectedPackageForBooking(null);
  };

  const openCreatorModal = () => setIsCreatorModalOpen(true);
  const closeCreatorModal = () => setIsCreatorModalOpen(false);

  const openLookupModal = () => setIsLookupModalOpen(true);
  const closeLookupModal = () => setIsLookupModalOpen(false);

  // Admin access gatekeeper
  const requestAdminAccess = (targetTab?: AdminTabType) => {
    if (targetTab) {
      setAdminActiveTab(targetTab);
    }
    if (isAdminAuthenticated) {
      setIsAdminModalOpen(true);
    } else {
      setIsAdminPinModalOpen(true);
    }
  };

  const openAdminModal = (targetTab?: AdminTabType) => {
    if (targetTab) {
      setAdminActiveTab(targetTab);
    }
    if (isAdminAuthenticated) {
      setIsAdminModalOpen(true);
    } else {
      setIsAdminPinModalOpen(true);
    }
  };

  const closeAdminModal = () => setIsAdminModalOpen(false);
  const openAdminPinModal = () => setIsAdminPinModalOpen(true);
  const closeAdminPinModal = () => setIsAdminPinModalOpen(false);

  const verifyAdminPin = (enteredPin: string): boolean => {
    const currentPin = paymentSettings.adminPin || '2026';
    if (enteredPin.trim() === currentPin.trim()) {
      setIsAdminAuthenticated(true);
      try {
        sessionStorage.setItem(STORAGE_KEYS.ADMIN_AUTH, 'true');
      } catch {}
      setIsAdminPinModalOpen(false);
      setIsAdminModalOpen(true);
      return true;
    }
    return false;
  };

  const logoutAdmin = () => {
    setIsAdminAuthenticated(false);
    setIsAdminModalOpen(false);
    try {
      sessionStorage.removeItem(STORAGE_KEYS.ADMIN_AUTH);
    } catch {}
  };

  // Cover / Hero mutations
  const updateHeroSettings = (updated: Partial<HeroCoverSettings>) => {
    setHeroSettings(prev => ({ ...prev, ...updated }));
  };

  const resetHeroSettings = () => {
    setHeroSettings(INITIAL_HERO_SETTINGS);
  };

  // Creator applications mutations
  const addCreatorApplication = (appData: Omit<CreatorApplication, 'id' | 'appliedAt' | 'status'>): CreatorApplication => {
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const newApp: CreatorApplication = {
      ...appData,
      id: `CREATOR-APP-${randomSuffix}`,
      status: 'PENDING',
      appliedAt: new Date().toISOString()
    };
    setCreatorApplications(prev => [newApp, ...prev]);
    return newApp;
  };

  const updateCreatorApplicationStatus = (id: string, status: CreatorApplication['status']) => {
    setCreatorApplications(prev => prev.map(a => a.id === id ? { ...a, status } : a));
  };

  const deleteCreatorApplication = (id: string) => {
    setCreatorApplications(prev => prev.filter(a => a.id !== id));
  };

  // Admin Tab & Category actions
  const addCategory = (newCat: Omit<EventCategory, 'id' | 'slug'>) => {
    const id = `cat-${Date.now()}`;
    const slug = newCat.name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    const created: EventCategory = {
      ...newCat,
      id,
      slug,
      isCustom: true,
      packages: newCat.packages && newCat.packages.length > 0 ? newCat.packages : [
        {
          id: `pkg-${Date.now()}-1`,
          name: 'Standard Reel Package',
          price: newCat.basePrice || 4999,
          reelsCount: 2,
          durationHours: 3,
          turnaroundHours: 24,
          features: [
            '2 Edited 4K 60fps Reels',
            'iPhone 16 Pro Max + Motorized Gimbal',
            'Color Graded with Trending Music',
            'Full raw footage delivery'
          ]
        }
      ]
    };
    setCategories(prev => [...prev, created]);
    setActiveCategoryId(id);
  };

  const updateCategory = (id: string, updated: Partial<EventCategory>) => {
    setCategories(prev => prev.map(c => c.id === id ? { ...c, ...updated } : c));
  };

  const deleteCategory = (id: string) => {
    setCategories(prev => prev.filter(c => c.id !== id));
  };

  // Package actions
  const updatePackage = (categoryId: string, packageId: string, updated: Partial<Package>) => {
    setCategories(prev => prev.map(c => {
      if (c.id !== categoryId) return c;
      return {
        ...c,
        packages: c.packages.map(p => p.id === packageId ? { ...p, ...updated } : p)
      };
    }));
  };

  const addPackage = (categoryId: string, newPkg: Omit<Package, 'id'>) => {
    const pkgId = `pkg-${Date.now()}`;
    setCategories(prev => prev.map(c => {
      if (c.id !== categoryId) return c;
      return {
        ...c,
        packages: [...c.packages, { ...newPkg, id: pkgId }]
      };
    }));
  };

  const deletePackage = (categoryId: string, packageId: string) => {
    setCategories(prev => prev.map(c => {
      if (c.id !== categoryId) return c;
      return {
        ...c,
        packages: c.packages.filter(p => p.id !== packageId)
      };
    }));
  };

  // Payment settings
  const updatePaymentSettings = (updated: Partial<PaymentSettings>) => {
    setPaymentSettings(prev => ({ ...prev, ...updated }));
  };

  // Bookings
  const addBooking = (bookingData: Omit<Booking, 'id' | 'createdAt' | 'paymentStatus' | 'deliverablesStatus'>): Booking => {
    const randomSuffix = Math.floor(10000 + Math.random() * 90000);
    const newBooking: Booking = {
      ...bookingData,
      id: `REEL-${randomSuffix}`,
      createdAt: new Date().toISOString(),
      paymentStatus: 'PENDING_VERIFICATION',
      deliverablesStatus: 'NOT_STARTED'
    };
    setBookings(prev => [newBooking, ...prev]);
    return newBooking;
  };

  const updateBookingStatus = (id: string, paymentStatus: Booking['paymentStatus'], deliverablesStatus?: Booking['deliverablesStatus']) => {
    setBookings(prev => prev.map(b => {
      if (b.id !== id) return b;
      return {
        ...b,
        paymentStatus,
        ...(deliverablesStatus ? { deliverablesStatus } : {})
      };
    }));
  };

  const deleteBooking = (id: string) => {
    setBookings(prev => prev.filter(b => b.id !== id));
  };

  const resetAllData = () => {
    setCategories(INITIAL_CATEGORIES);
    setPaymentSettings(INITIAL_PAYMENT_SETTINGS);
    setBookings(INITIAL_BOOKINGS);
    setHeroSettings(INITIAL_HERO_SETTINGS);
    setCreatorApplications(INITIAL_CREATOR_APPLICATIONS);
    setActiveCategoryId(INITIAL_CATEGORIES[0].id);
    localStorage.removeItem(STORAGE_KEYS.CATEGORIES);
    localStorage.removeItem(STORAGE_KEYS.PAYMENT_SETTINGS);
    localStorage.removeItem(STORAGE_KEYS.BOOKINGS);
    localStorage.removeItem(STORAGE_KEYS.HERO_SETTINGS);
    localStorage.removeItem(STORAGE_KEYS.CREATOR_APPLICATIONS);
  };

  return (
    <AppContext.Provider
      value={{
        categories,
        paymentSettings,
        bookings,
        heroSettings,
        creatorApplications,
        activeCategoryId,
        setActiveCategoryId,
        isBookingModalOpen,
        selectedCategoryForBooking,
        selectedPackageForBooking,
        openBookingModal,
        closeBookingModal,
        isCreatorModalOpen,
        openCreatorModal,
        closeCreatorModal,
        addCreatorApplication,
        updateCreatorApplicationStatus,
        deleteCreatorApplication,
        isLookupModalOpen,
        openLookupModal,
        closeLookupModal,
        isAdminAuthenticated,
        isAdminModalOpen,
        isAdminPinModalOpen,
        adminActiveTab,
        setAdminActiveTab,
        requestAdminAccess,
        openAdminModal,
        closeAdminModal,
        openAdminPinModal,
        closeAdminPinModal,
        verifyAdminPin,
        logoutAdmin,
        updateHeroSettings,
        resetHeroSettings,
        addCategory,
        updateCategory,
        deleteCategory,
        updatePackage,
        addPackage,
        deletePackage,
        updatePaymentSettings,
        addBooking,
        updateBookingStatus,
        deleteBooking,
        resetAllData,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
