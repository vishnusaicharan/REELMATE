import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  HeartHandshake, 
  Car, 
  PartyPopper, 
  Camera, 
  Sparkles, 
  Music, 
  Flame, 
  Trophy, 
  Check, 
  Clock, 
  Film, 
  PlusCircle, 
  Edit3 
} from 'lucide-react';
import { formatCurrency } from '../utils/qrHelper';
import { EventCategory, Package } from '../types';

export const CategoryTabsSection: React.FC = () => {
  const { 
    categories, 
    activeCategoryId, 
    setActiveCategoryId, 
    openBookingModal, 
    openAdminModal,
    openCreatorModal,
    paymentSettings,
    isAdminAuthenticated
  } = useApp();

  const activeCategory = categories.find(c => c.id === activeCategoryId) || categories[0];

  // Map icon names safely
  const getCategoryIcon = (iconName: string) => {
    switch (iconName) {
      case 'HeartHandshake': return <HeartHandshake className="h-4 w-4" />;
      case 'Car': return <Car className="h-4 w-4" />;
      case 'PartyPopper': return <PartyPopper className="h-4 w-4" />;
      case 'Camera': return <Camera className="h-4 w-4" />;
      case 'Music': return <Music className="h-4 w-4" />;
      case 'Flame': return <Flame className="h-4 w-4" />;
      case 'Trophy': return <Trophy className="h-4 w-4" />;
      default: return <Sparkles className="h-4 w-4" />;
    }
  };

  return (
    <section id="categories" className="py-16 lg:py-24 bg-zinc-950 text-white scroll-mt-14">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-amber-400 uppercase tracking-wider mb-2">
              <Film className="h-3.5 w-3.5" />
              <span>Tailored Creator Packages</span>
            </div>
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold tracking-tight text-white text-balance">
              Choose Your Event Type &amp; Deliverables
            </h2>
          </div>

          {(isAdminAuthenticated || !paymentSettings.hideAdminButtonFromPublic) && (
            <div className="flex items-center gap-3">
              <button
                onClick={() => openAdminModal('TABS')}
                className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-amber-300 bg-amber-500/10 border border-amber-500/30 rounded-lg hover:border-amber-400 hover:text-white transition-all cursor-pointer whitespace-nowrap"
              >
                <PlusCircle className="h-3.5 w-3.5 text-amber-400" />
                <span>Admin: Add Tab or Edit Prices</span>
              </button>
            </div>
          )}
        </div>

        {/* Interactive Segmented Tab Controls (Zero pill abuse, functional segmented bar) */}
        <div className="flex items-center gap-2 p-1.5 bg-zinc-900/90 border border-zinc-800 rounded-xl overflow-x-auto no-scrollbar mb-10">
          {categories.map((category) => {
            const isActive = category.id === activeCategoryId;
            return (
              <button
                key={category.id}
                onClick={() => setActiveCategoryId(category.id)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-semibold transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                  isActive
                    ? 'bg-amber-400 text-zinc-950 shadow-md font-bold'
                    : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/60'
                }`}
              >
                <span>{getCategoryIcon(category.iconName)}</span>
                <span>{category.name}</span>
                {category.isCustom && (
                  <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${isActive ? 'bg-zinc-950/20 text-zinc-950' : 'bg-zinc-800 text-zinc-400'}`}>
                    Custom
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Active Category Marquee Details */}
        {activeCategory && (
          <div className="space-y-10">
            {/* Category Banner Card */}
            <div className="relative rounded-2xl overflow-hidden border border-zinc-800 bg-zinc-900/60 p-6 sm:p-8">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
                <div className="lg:col-span-7 space-y-3">
                  <div className="flex items-center gap-2 text-xs text-amber-400 font-medium">
                    <span>{activeCategory.name}</span>
                    <span aria-hidden="true">·</span>
                    <span>Starting from {formatCurrency(activeCategory.basePrice, paymentSettings.currencySymbol)}</span>
                  </div>
                  <h3 className="text-xl sm:text-2xl font-bold text-white">
                    {activeCategory.tagline}
                  </h3>
                  <p className="text-sm text-zinc-400 leading-relaxed max-w-2xl">
                    {activeCategory.description}
                  </p>
                </div>

                <div className="lg:col-span-5">
                  <div className="rounded-xl overflow-hidden border border-zinc-700/60 max-h-52 relative group">
                    <img
                      src={activeCategory.coverImage}
                      alt={activeCategory.name}
                      className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-500"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-zinc-950/80 via-transparent to-transparent" />
                    <div className="absolute bottom-3 left-3 text-xs font-semibold text-white">
                      Shot on iPhone 16 Pro Max
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Packages Grid for this Category */}
            <div>
              <div className="flex items-center justify-between mb-6">
                <h4 className="text-lg font-bold text-white flex items-center gap-2">
                  <span>Available Packages for {activeCategory.name}</span>
                  <span className="text-xs text-zinc-400 font-normal">
                    ({activeCategory.packages.length} options)
                  </span>
                </h4>
                <span className="text-xs text-zinc-400">
                  All packages include color grading &amp; trending audio
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {activeCategory.packages.map((pkg: Package) => (
                  <div
                    key={pkg.id}
                    className={`relative flex flex-col justify-between rounded-2xl border p-6 transition-all ${
                      pkg.popular
                        ? 'border-amber-500/70 bg-gradient-to-b from-amber-500/10 via-zinc-900/90 to-zinc-900 shadow-xl shadow-amber-500/5'
                        : 'border-zinc-800 bg-zinc-900/80 hover:border-zinc-700'
                    }`}
                  >
                    {/* Popular indicator */}
                    {pkg.popular && (
                      <div className="absolute -top-3 left-6 px-3 py-0.5 rounded-full bg-gradient-to-r from-amber-400 to-yellow-300 text-[11px] font-black text-zinc-950 shadow-sm uppercase tracking-wider">
                        Most Booked Choice
                      </div>
                    )}

                    <div>
                      {/* Package Header */}
                      <div className="flex items-start justify-between gap-4 mb-3">
                        <h5 className="text-lg font-bold text-white leading-tight">
                          {pkg.name}
                        </h5>
                        <div className="text-right shrink-0">
                          <span className="text-2xl font-black text-amber-400 tabular-nums">
                            {formatCurrency(pkg.price, paymentSettings.currencySymbol)}
                          </span>
                        </div>
                      </div>

                      {/* Highlights Strip */}
                      <div className="flex items-center gap-3 text-xs text-zinc-400 py-3 border-y border-zinc-800/80 mb-5">
                        <div className="flex items-center gap-1.5 font-medium text-zinc-300">
                          <Film className="h-3.5 w-3.5 text-amber-400" />
                          <span>{pkg.reelsCount} Edited Reels</span>
                        </div>
                        <span className="text-zinc-700" aria-hidden="true">·</span>
                        <div className="flex items-center gap-1.5">
                          <Clock className="h-3.5 w-3.5 text-amber-400" />
                          <span>{pkg.durationHours} Hours Shoot</span>
                        </div>
                        <span className="text-zinc-700" aria-hidden="true">·</span>
                        <div className="flex items-center gap-1.5 text-emerald-400 font-medium">
                          <span>{pkg.turnaroundHours}h Delivery</span>
                        </div>
                      </div>

                      {/* Features List */}
                      <ul className="space-y-2.5 mb-6 text-xs text-zinc-300">
                        {pkg.features.map((feature, idx) => (
                          <li key={idx} className="flex items-start gap-2.5">
                            <Check className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Booking Action */}
                    <div className="pt-4 border-t border-zinc-800/60 mt-auto">
                      <button
                        onClick={() => openBookingModal(activeCategory, pkg)}
                        className={`w-full py-3 px-4 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
                          pkg.popular
                            ? 'bg-amber-400 text-zinc-950 hover:bg-amber-300 shadow-md shadow-amber-500/20 active:scale-98'
                            : 'bg-zinc-800 text-white hover:bg-zinc-700 active:scale-98'
                        }`}
                      >
                        <span>Select &amp; Pick Date / Time</span>
                      </button>
                      <p className="text-[11px] text-center text-zinc-500 mt-2">
                        Lock slot with {paymentSettings.advancePercentage}% UPI advance
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Creator Onboarding Callout Banner */}
        <div className="mt-12 p-6 rounded-2xl bg-gradient-to-r from-zinc-900 via-zinc-900/90 to-amber-950/20 border border-zinc-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="h-10 w-10 rounded-xl bg-amber-400/15 border border-amber-400/30 flex items-center justify-center text-amber-400 shrink-0">
              <Camera className="h-5 w-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">Own an iPhone 14/15/16 Pro &amp; love shooting reels?</h4>
              <p className="text-xs text-zinc-400 mt-0.5">
                Join Reelmate as a creator! Earn ₹4,000 to ₹10,000+ per event shoot in your city.
              </p>
            </div>
          </div>
          <button
            onClick={openCreatorModal}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-zinc-950 text-xs font-bold transition-all shadow-md shadow-amber-500/10 cursor-pointer whitespace-nowrap shrink-0"
          >
            <Sparkles className="h-3.5 w-3.5" />
            <span>Become a Creator</span>
          </button>
        </div>

      </div>
    </section>
  );
};
