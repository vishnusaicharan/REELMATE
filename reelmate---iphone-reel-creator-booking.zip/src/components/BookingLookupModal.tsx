import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { X, Search, CheckCircle2, Clock, MapPin, Calendar, Smartphone } from 'lucide-react';
import { formatCurrency } from '../utils/qrHelper';
import { Booking } from '../types';

export const BookingLookupModal: React.FC = () => {
  const { isLookupModalOpen, closeLookupModal, bookings, paymentSettings } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [searchedBooking, setSearchedBooking] = useState<Booking | null>(null);
  const [hasSearched, setHasSearched] = useState(false);

  if (!isLookupModalOpen) return null;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const query = searchQuery.trim().toLowerCase();
    if (!query) return;

    const found = bookings.find(
      b => b.id.toLowerCase() === query || 
           b.clientPhone.replace(/[^0-9]/g, '').includes(query.replace(/[^0-9]/g, '')) ||
           b.clientName.toLowerCase().includes(query)
    );

    setSearchedBooking(found || null);
    setHasSearched(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="relative w-full max-w-lg bg-zinc-900 border border-zinc-800 rounded-2xl shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800 bg-zinc-950/60">
          <div>
            <h3 className="text-base font-bold text-white">Track Your Booking Status</h3>
            <p className="text-xs text-zinc-400">Enter your Booking ID (e.g. REEL-84192) or phone number</p>
          </div>
          <button
            onClick={closeLookupModal}
            className="p-1.5 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800 transition-colors cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Search Input Form */}
        <form onSubmit={handleSearch} className="p-6 pb-4">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <input
                type="text"
                placeholder="Booking ID (e.g. REEL-84192) or Mobile No"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-400 pl-9"
              />
              <Search className="absolute left-3 top-3 h-4 w-4 text-zinc-500" />
            </div>
            <button
              type="submit"
              className="px-5 py-2.5 text-xs font-bold text-zinc-950 bg-amber-400 rounded-xl hover:bg-amber-300 transition-colors cursor-pointer shrink-0"
            >
              Search
            </button>
          </div>
        </form>

        {/* Results Area */}
        <div className="px-6 pb-6">
          {searchedBooking ? (
            <div className="p-5 rounded-2xl border border-zinc-800 bg-zinc-950 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
                <div>
                  <span className="text-[11px] text-zinc-500">Booking Reference</span>
                  <p className="font-mono text-sm font-bold text-amber-400">{searchedBooking.id}</p>
                </div>
                <div className="text-right">
                  <span className="text-[11px] text-zinc-500">Payment Status</span>
                  <p className={`text-xs font-bold ${searchedBooking.paymentStatus === 'VERIFIED' ? 'text-emerald-400' : 'text-amber-400'}`}>
                    {searchedBooking.paymentStatus === 'VERIFIED' ? 'Verified & Confirmed' : 'Payment Under Verification'}
                  </p>
                </div>
              </div>

              <div className="space-y-2 text-xs">
                <div className="flex items-center gap-2 text-zinc-300">
                  <Calendar className="h-4 w-4 text-amber-400 shrink-0" />
                  <span>{searchedBooking.eventDate} at {searchedBooking.startTime} ({searchedBooking.durationHours} hrs)</span>
                </div>
                <div className="flex items-center gap-2 text-zinc-300">
                  <MapPin className="h-4 w-4 text-amber-400 shrink-0" />
                  <span className="truncate">{searchedBooking.venueLocation}</span>
                </div>
                <div className="flex items-center gap-2 text-zinc-300">
                  <Smartphone className="h-4 w-4 text-amber-400 shrink-0" />
                  <span>{searchedBooking.categoryName} · {searchedBooking.packageName}</span>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-zinc-900 border border-zinc-800/80 text-[11px] text-zinc-400 flex items-center justify-between">
                <span>Amount Paid ({searchedBooking.paymentMode}):</span>
                <span className="font-bold text-white tabular-nums">
                  {formatCurrency(searchedBooking.advancePaid, paymentSettings.currencySymbol)}
                </span>
              </div>

              <a
                href={`https://wa.me/${paymentSettings.supportPhone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(`Hi Reelmate! I'm checking status of booking ${searchedBooking.id}.`)}`}
                target="_blank"
                rel="noreferrer"
                className="w-full py-2.5 px-4 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <span>Contact Shoot Coordinator</span>
              </a>
            </div>
          ) : hasSearched ? (
            <div className="p-6 text-center rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-zinc-400">
              No booking found for &quot;{searchQuery}&quot;. Please verify your ID or contact support on WhatsApp.
            </div>
          ) : (
            <div className="text-center py-4 text-xs text-zinc-500">
              Quick search: Try demo booking <span className="text-amber-400 font-mono">REEL-84192</span>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
