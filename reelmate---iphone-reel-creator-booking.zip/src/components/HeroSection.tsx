import React from 'react';
import { Smartphone, Zap, Sparkles, QrCode, ArrowDown, Edit3, Image as ImageIcon } from 'lucide-react';
import { useApp } from '../context/AppContext';

interface HeroSectionProps {
  onExploreClick: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onExploreClick }) => {
  const { heroSettings, isAdminAuthenticated, openAdminModal, openCreatorModal } = useApp();

  return (
    <section className="relative overflow-hidden bg-zinc-950 pt-8 pb-16 lg:pt-14 lg:pb-24 border-b border-zinc-900">
      {/* Background glow subtleties */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-amber-500/10 blur-[130px] pointer-events-none rounded-full" />
      
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Admin Quick Edit Bar (only visible when admin is authenticated) */}
        {isAdminAuthenticated && (
          <div className="mb-6 p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-between text-xs text-amber-300">
            <div className="flex items-center gap-2">
              <ImageIcon className="h-4 w-4 text-amber-400" />
              <span className="font-semibold">Cover Page Active</span>
              <span className="text-zinc-500">·</span>
              <span className="text-zinc-400 hidden sm:inline">You are viewing live hero cover content.</span>
            </div>
            <button
              onClick={() => openAdminModal('COVER')}
              className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-amber-400 text-zinc-950 font-bold hover:bg-amber-300 transition-colors cursor-pointer"
            >
              <Edit3 className="h-3.5 w-3.5" />
              <span>Edit Cover Page &amp; Photo</span>
            </button>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          
          {/* Left Column: Proposition & CTA */}
          <div className="lg:col-span-7 flex flex-col justify-center">
            {/* Quiet text kicker */}
            <div className="flex items-center gap-2 text-xs font-medium text-amber-400 mb-4 tracking-wide uppercase">
              <Sparkles className="h-3.5 w-3.5" />
              <span>{heroSettings.badgeText}</span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-[1.15] text-balance">
              {heroSettings.headline}
            </h1>

            <p className="mt-5 text-base sm:text-lg text-zinc-400 leading-relaxed max-w-2xl">
              {heroSettings.subheadline}
            </p>

            {/* CTA action buttons */}
            <div className="mt-8 flex flex-wrap items-center gap-3 sm:gap-4">
              <button
                onClick={onExploreClick}
                className="flex items-center gap-2 px-6 py-3.5 text-sm font-bold text-zinc-950 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-300 rounded-xl hover:brightness-110 active:scale-98 transition-all shadow-lg shadow-amber-500/20 cursor-pointer whitespace-nowrap"
              >
                <span>{heroSettings.primaryCtaText}</span>
                <ArrowDown className="h-4 w-4" />
              </button>

              <button
                onClick={openCreatorModal}
                className="flex items-center gap-2 px-5 py-3.5 text-sm font-semibold text-white bg-zinc-900 border border-zinc-700/80 rounded-xl hover:border-amber-400 hover:bg-zinc-850 active:scale-98 transition-all cursor-pointer whitespace-nowrap"
              >
                <Smartphone className="h-4 w-4 text-amber-400" />
                <span>Become a Creator</span>
              </button>

              <div className="flex items-center gap-2.5 px-3.5 py-3 rounded-xl border border-zinc-800 bg-zinc-900/60 text-xs text-zinc-300">
                <QrCode className="h-4 w-4 text-amber-400 shrink-0" />
                <span>{heroSettings.secondaryCtaText}</span>
              </div>
            </div>

            {/* Quick trust metrics */}
            <div className="mt-8 pt-6 border-t border-zinc-900 flex flex-wrap items-center gap-6 text-xs text-zinc-400">
              <div className="flex items-center gap-2">
                <span className="font-semibold text-zinc-200">{heroSettings.statEventsCount}</span>
              </div>
              <span className="text-zinc-700" aria-hidden="true">·</span>
              <div className="flex items-center gap-2">
                <span className="font-semibold text-zinc-200">{heroSettings.statRating}</span>
              </div>
              <span className="text-zinc-700" aria-hidden="true">·</span>
              <div className="flex items-center gap-2">
                <span className="font-semibold text-zinc-200">{heroSettings.statTurnaround}</span>
              </div>
            </div>
          </div>

          {/* Right Column: Hero Cinematic Image Focal Carrier */}
          <div className="lg:col-span-5 relative group">
            <div className="relative mx-auto max-w-md lg:max-w-none rounded-2xl overflow-hidden border border-zinc-800/80 bg-zinc-900 shadow-2xl">
              <img
                src={heroSettings.coverImage}
                alt="Professional iPhone reel videographer filming event with motorized stabilizer"
                className="w-full h-auto aspect-[4/3] sm:aspect-[16/10] lg:aspect-[4/3] object-cover"
                referrerPolicy="no-referrer"
              />
              
              {/* Scrim & Live Camera UI Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-zinc-950/90 via-zinc-950/20 to-transparent pointer-events-none" />

              {/* Viewfinder UI elements */}
              <div className="absolute top-4 left-4 right-4 flex items-center justify-between pointer-events-none text-[11px] font-mono text-zinc-200">
                <span className="px-2 py-0.5 rounded bg-black/60 backdrop-blur-sm border border-white/10 text-red-400 font-semibold flex items-center gap-1.5">
                  <span className="h-1.5 w-1.5 rounded-full bg-red-500 animate-pulse" />
                  REC · 4K 60
                </span>
                <span className="px-2 py-0.5 rounded bg-black/60 backdrop-blur-sm border border-white/10">
                  ProRes LOG
                </span>
              </div>

              {/* Bottom card highlight */}
              <div className="absolute bottom-4 left-4 right-4 p-3.5 rounded-xl bg-zinc-900/90 backdrop-blur-md border border-zinc-800/90 text-left">
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="font-semibold text-white">Live Shoot Spec</span>
                  <span className="text-amber-400 font-mono">100% Vertical (9:16)</span>
                </div>
                <p className="text-[11px] text-zinc-400">
                  {heroSettings.cameraSpecBadge}
                </p>
              </div>

              {/* Quick edit overlay for admin */}
              {isAdminAuthenticated && (
                <button
                  onClick={() => openAdminModal('COVER')}
                  className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity px-2.5 py-1.5 rounded-lg bg-zinc-950/80 border border-amber-400/50 text-amber-300 text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-lg"
                >
                  <Edit3 className="h-3 w-3" />
                  <span>Change Cover</span>
                </button>
              )}
            </div>
          </div>
        </div>

        {/* 4-Column KPI / Trust Strip below hero split */}
        <div className="mt-14 grid grid-cols-2 md:grid-cols-4 gap-4 border-t border-zinc-800/80 pt-8">
          <div className="flex items-start gap-3 p-4 rounded-xl bg-zinc-900/40 border border-zinc-800/60">
            <Smartphone className="h-5 w-5 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-bold text-white">4K 60fps ProRes</p>
              <p className="text-xs text-zinc-400 mt-0.5">Cinematic depth, HDR color grading</p>
            </div>
          </div>

          <div className="flex items-start gap-3 p-4 rounded-xl bg-zinc-900/40 border border-zinc-800/60">
            <Zap className="h-5 w-5 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-bold text-white">24-Hr Turnaround</p>
              <p className="text-xs text-zinc-400 mt-0.5">Post while the event hype is fresh</p>
            </div>
          </div>

          <div className="flex items-start gap-3 p-4 rounded-xl bg-zinc-900/40 border border-zinc-800/60">
            <Sparkles className="h-5 w-5 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-bold text-white">Trending Audio Sync</p>
              <p className="text-xs text-zinc-400 mt-0.5">Viral beat drops &amp; high retention edits</p>
            </div>
          </div>

          <div className="flex items-start gap-3 p-4 rounded-xl bg-zinc-900/40 border border-zinc-800/60">
            <QrCode className="h-5 w-5 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-bold text-white">Instant UPI Lock</p>
              <p className="text-xs text-zinc-400 mt-0.5">Scan QR &amp; lock your date in 60s</p>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
