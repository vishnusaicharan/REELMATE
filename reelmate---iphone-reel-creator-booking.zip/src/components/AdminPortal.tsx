import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, 
  Settings, 
  Plus, 
  Trash2, 
  Edit2, 
  QrCode, 
  CreditCard, 
  DollarSign, 
  Check, 
  Upload, 
  Eye, 
  FolderPlus, 
  FileCheck, 
  AlertTriangle,
  RotateCcw,
  ExternalLink,
  MessageSquare,
  Lock,
  Unlock,
  Key,
  Shield,
  LogOut,
  EyeOff,
  LayoutTemplate,
  Image as ImageIcon,
  Camera,
  Smartphone,
  CheckCircle2,
  User,
  Phone,
  MapPin,
  Instagram,
  Sparkles,
  Sliders
} from 'lucide-react';
import { formatCurrency } from '../utils/qrHelper';
import { EventCategory, Package, Booking } from '../types';

export const AdminPortal: React.FC = () => {
  const { 
    isAdminModalOpen, 
    closeAdminModal, 
    categories, 
    addCategory, 
    updateCategory, 
    deleteCategory, 
    updatePackage, 
    addPackage, 
    deletePackage,
    paymentSettings, 
    updatePaymentSettings, 
    bookings, 
    updateBookingStatus, 
    deleteBooking,
    resetAllData,
    logoutAdmin,
    heroSettings,
    updateHeroSettings,
    resetHeroSettings,
    creatorApplications,
    updateCreatorApplicationStatus,
    deleteCreatorApplication,
    adminActiveTab,
    setAdminActiveTab
  } = useApp();

  const [applicationFilter, setApplicationFilter] = useState<'ALL' | 'PENDING' | 'APPROVED' | 'REJECTED'>('ALL');

  // Cover Page states
  const [coverImageInput, setCoverImageInput] = useState(heroSettings.coverImage);
  const [coverHeadlineInput, setCoverHeadlineInput] = useState(heroSettings.headline);
  const [coverSubheadlineInput, setCoverSubheadlineInput] = useState(heroSettings.subheadline);
  const [coverBadgeInput, setCoverBadgeInput] = useState(heroSettings.badgeText);
  const [coverPrimaryCtaInput, setCoverPrimaryCtaInput] = useState(heroSettings.primaryCtaText);
  const [coverSecondaryCtaInput, setCoverSecondaryCtaInput] = useState(heroSettings.secondaryCtaText);
  const [coverCameraSpecInput, setCoverCameraSpecInput] = useState(heroSettings.cameraSpecBadge);
  const [coverEventsCountInput, setCoverEventsCountInput] = useState(heroSettings.statEventsCount);
  const [coverRatingInput, setCoverRatingInput] = useState(heroSettings.statRating);
  const [coverTurnaroundInput, setCoverTurnaroundInput] = useState(heroSettings.statTurnaround);
  const [coverSavedMsg, setCoverSavedMsg] = useState(false);

  // Security states
  const [adminPinInput, setAdminPinInput] = useState(paymentSettings.adminPin || '2026');
  const [hidePublicInput, setHidePublicInput] = useState(paymentSettings.hideAdminButtonFromPublic ?? true);
  const [securitySavedMsg, setSecuritySavedMsg] = useState(false);

  // Tab / Category creation state
  const [isAddingCategory, setIsAddingCategory] = useState(false);
  const [newCatName, setNewCatName] = useState('');
  const [newCatTagline, setNewCatTagline] = useState('');
  const [newCatDescription, setNewCatDescription] = useState('');
  const [newCatBasePrice, setNewCatBasePrice] = useState(6999);
  const [newCatIcon, setNewCatIcon] = useState('Camera');
  const [newCatImage, setNewCatImage] = useState('/src/assets/images/hero_reel_creator_1791705571989.jpg');

  // Edit category state
  const [editingCatId, setEditingCatId] = useState<string | null>(null);
  const [editCatName, setEditCatName] = useState('');
  const [editCatTagline, setEditCatTagline] = useState('');
  const [editCatDescription, setEditCatDescription] = useState('');
  const [editCatBasePrice, setEditCatBasePrice] = useState(0);

  // Selected Category for Package Editing
  const [selectedCatForPackages, setSelectedCatForPackages] = useState<string>(categories[0]?.id || '');
  
  // Package editing state
  const [editingPkgId, setEditingPkgId] = useState<string | null>(null);
  const [pkgEditName, setPkgEditName] = useState('');
  const [pkgEditPrice, setPkgEditPrice] = useState(0);
  const [pkgEditReels, setPkgEditReels] = useState(2);
  const [pkgEditDuration, setPkgEditDuration] = useState(3);
  const [pkgEditTurnaround, setPkgEditTurnaround] = useState(24);
  const [pkgEditFeaturesText, setPkgEditFeaturesText] = useState('');

  // Add package state
  const [isAddingPkg, setIsAddingPkg] = useState(false);
  const [newPkgName, setNewPkgName] = useState('');
  const [newPkgPrice, setNewPkgPrice] = useState(7999);
  const [newPkgReels, setNewPkgReels] = useState(3);
  const [newPkgDuration, setNewPkgDuration] = useState(4);
  const [newPkgTurnaround, setNewPkgTurnaround] = useState(12);
  const [newPkgFeaturesText, setNewPkgFeaturesText] = useState('3 Edited 4K 60fps Reels\nTurnaround within 12 hours\nColor grading & Audio mix\nAirDrop all raw video clips');

  // Payment form states
  const [upiIdInput, setUpiIdInput] = useState(paymentSettings.upiId);
  const [payeeNameInput, setPayeeNameInput] = useState(paymentSettings.payeeName);
  const [qrTypeInput, setQrTypeInput] = useState<'dynamic' | 'custom_image'>(paymentSettings.qrCodeType);
  const [customQrImageInput, setCustomQrImageInput] = useState(paymentSettings.customQrImageUrl || '');
  const [advancePercentInput, setAdvancePercentInput] = useState(paymentSettings.advancePercentage);
  const [paymentNoteInput, setPaymentNoteInput] = useState(paymentSettings.paymentNote);
  const [supportPhoneInput, setSupportPhoneInput] = useState(paymentSettings.supportPhone);
  const [paymentSavedMessage, setPaymentSavedMessage] = useState(false);

  // Receipt preview modal state
  const [previewReceiptUrl, setPreviewReceiptUrl] = useState<string | null>(null);

  if (!isAdminModalOpen) return null;

  // Handlers for Categories
  const handleCreateCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) return;

    addCategory({
      name: newCatName.trim(),
      tagline: newCatTagline.trim() || 'Cinematic vertical 4K reels for your special event',
      description: newCatDescription.trim() || 'Professional mobile cinematography with express 24h delivery.',
      coverImage: newCatImage,
      iconName: newCatIcon,
      basePrice: Number(newCatBasePrice) || 4999,
      packages: [
        {
          id: `pkg-${Date.now()}-1`,
          name: 'Standard Reel Package',
          price: Number(newCatBasePrice) || 4999,
          reelsCount: 2,
          durationHours: 3,
          turnaroundHours: 24,
          features: [
            '2 Edited 4K 60fps Reels',
            'iPhone 16 Pro Max + Motorized Gimbal',
            'Color Graded with Trending Music',
            'Full raw footage delivery'
          ]
        }
      ]
    });

    setNewCatName('');
    setNewCatTagline('');
    setNewCatDescription('');
    setIsAddingCategory(false);
  };

  const handleStartEditCategory = (cat: EventCategory) => {
    setEditingCatId(cat.id);
    setEditCatName(cat.name);
    setEditCatTagline(cat.tagline);
    setEditCatDescription(cat.description);
    setEditCatBasePrice(cat.basePrice);
  };

  const handleSaveEditCategory = (id: string) => {
    updateCategory(id, {
      name: editCatName,
      tagline: editCatTagline,
      description: editCatDescription,
      basePrice: Number(editCatBasePrice),
    });
    setEditingCatId(null);
  };

  // Handlers for Packages
  const handleStartEditPackage = (pkg: Package) => {
    setEditingPkgId(pkg.id);
    setPkgEditName(pkg.name);
    setPkgEditPrice(pkg.price);
    setPkgEditReels(pkg.reelsCount);
    setPkgEditDuration(pkg.durationHours);
    setPkgEditTurnaround(pkg.turnaroundHours);
    setPkgEditFeaturesText(pkg.features.join('\n'));
  };

  const handleSavePackage = (catId: string, pkgId: string) => {
    const features = pkgEditFeaturesText
      .split('\n')
      .map(f => f.trim())
      .filter(Boolean);

    updatePackage(catId, pkgId, {
      name: pkgEditName,
      price: Number(pkgEditPrice),
      reelsCount: Number(pkgEditReels),
      durationHours: Number(pkgEditDuration),
      turnaroundHours: Number(pkgEditTurnaround),
      features,
    });
    setEditingPkgId(null);
  };

  const handleCreatePackage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCatForPackages || !newPkgName.trim()) return;

    const features = newPkgFeaturesText
      .split('\n')
      .map(f => f.trim())
      .filter(Boolean);

    addPackage(selectedCatForPackages, {
      name: newPkgName.trim(),
      price: Number(newPkgPrice),
      reelsCount: Number(newPkgReels),
      durationHours: Number(newPkgDuration),
      turnaroundHours: Number(newPkgTurnaround),
      features,
    });

    setNewPkgName('');
    setIsAddingPkg(false);
  };

  // Save Payments
  const handleSavePayments = (e: React.FormEvent) => {
    e.preventDefault();
    updatePaymentSettings({
      upiId: upiIdInput.trim(),
      payeeName: payeeNameInput.trim(),
      qrCodeType: qrTypeInput,
      customQrImageUrl: customQrImageInput,
      advancePercentage: Number(advancePercentInput),
      paymentNote: paymentNoteInput.trim(),
      supportPhone: supportPhoneInput.trim(),
    });
    setPaymentSavedMessage(true);
    setTimeout(() => setPaymentSavedMessage(false), 2500);
  };

  const handleCustomQrFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setCustomQrImageInput(reader.result as string);
        setQrTypeInput('custom_image');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveSecuritySettings = (e: React.FormEvent) => {
    e.preventDefault();
    updatePaymentSettings({
      adminPin: adminPinInput.trim() || '2026',
      hideAdminButtonFromPublic: hidePublicInput,
    });
    setSecuritySavedMsg(true);
    setTimeout(() => setSecuritySavedMsg(false), 2500);
  };

  const handleSaveCoverSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateHeroSettings({
      coverImage: coverImageInput.trim(),
      badgeText: coverBadgeInput.trim(),
      headline: coverHeadlineInput.trim(),
      subheadline: coverSubheadlineInput.trim(),
      primaryCtaText: coverPrimaryCtaInput.trim(),
      secondaryCtaText: coverSecondaryCtaInput.trim(),
      cameraSpecBadge: coverCameraSpecInput.trim(),
      statEventsCount: coverEventsCountInput.trim(),
      statRating: coverRatingInput.trim(),
      statTurnaround: coverTurnaroundInput.trim(),
    });
    setCoverSavedMsg(true);
    setTimeout(() => setCoverSavedMsg(false), 2500);
  };

  const handleCoverImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setCoverImageInput(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const currentCategoryForPackages = categories.find(c => c.id === selectedCatForPackages) || categories[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-5xl bg-zinc-900 border border-zinc-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Top Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800 bg-zinc-950">
          <div className="flex items-center gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/30">
              <Settings className="h-4 w-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <span>Creator Admin Control Center</span>
                <span className="text-[11px] font-normal px-2 py-0.5 rounded bg-amber-400/10 text-amber-400 border border-amber-400/20">
                  Live Management
                </span>
              </h3>
              <p className="text-xs text-zinc-400">
                Manage event tabs, pricing, payment QR &amp; UPI settings, and customer bookings.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                logoutAdmin();
                closeAdminModal();
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-500/10 border border-red-500/25 text-red-400 hover:bg-red-500/20 text-xs font-semibold cursor-pointer transition-colors"
              title="Lock Admin Portal and Log Out"
            >
              <LogOut className="h-3.5 w-3.5" />
              <span>Log Out &amp; Lock</span>
            </button>
            <button
              onClick={closeAdminModal}
              className="p-1.5 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800 transition-colors cursor-pointer"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1 px-6 py-2.5 bg-zinc-950/70 border-b border-zinc-800 overflow-x-auto text-xs font-semibold">
          <button
            onClick={() => setAdminActiveTab('COVER')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-all cursor-pointer whitespace-nowrap ${
              adminActiveTab === 'COVER'
                ? 'bg-amber-400 text-zinc-950 font-bold'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/60'
            }`}
          >
            <LayoutTemplate className="h-3.5 w-3.5" />
            <span>Cover Page &amp; Hero</span>
          </button>

          <button
            onClick={() => setAdminActiveTab('TABS')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-all cursor-pointer whitespace-nowrap ${
              adminActiveTab === 'TABS'
                ? 'bg-amber-400 text-zinc-950 font-bold'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/60'
            }`}
          >
            <FolderPlus className="h-3.5 w-3.5" />
            <span>Event Tabs &amp; Categories ({categories.length})</span>
          </button>

          <button
            onClick={() => setAdminActiveTab('PRICES')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-all cursor-pointer whitespace-nowrap ${
              adminActiveTab === 'PRICES'
                ? 'bg-amber-400 text-zinc-950 font-bold'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/60'
            }`}
          >
            <DollarSign className="h-3.5 w-3.5" />
            <span>Edit Prices &amp; Packages</span>
          </button>

          <button
            onClick={() => setAdminActiveTab('PAYMENTS')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-all cursor-pointer whitespace-nowrap ${
              adminActiveTab === 'PAYMENTS'
                ? 'bg-amber-400 text-zinc-950 font-bold'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/60'
            }`}
          >
            <QrCode className="h-3.5 w-3.5" />
            <span>UPI ID &amp; QR Settings</span>
          </button>

          <button
            onClick={() => setAdminActiveTab('BOOKINGS')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-all cursor-pointer whitespace-nowrap ${
              adminActiveTab === 'BOOKINGS'
                ? 'bg-amber-400 text-zinc-950 font-bold'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/60'
            }`}
          >
            <FileCheck className="h-3.5 w-3.5" />
            <span>Client Bookings ({bookings.length})</span>
          </button>

          <button
            onClick={() => setAdminActiveTab('APPLICATIONS')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-all cursor-pointer whitespace-nowrap ${
              adminActiveTab === 'APPLICATIONS'
                ? 'bg-amber-400 text-zinc-950 font-bold'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/60'
            }`}
          >
            <Camera className="h-3.5 w-3.5" />
            <span>Creator Applications ({creatorApplications.length})</span>
          </button>

          <button
            onClick={() => setAdminActiveTab('SECURITY')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-all cursor-pointer whitespace-nowrap ${
              adminActiveTab === 'SECURITY'
                ? 'bg-amber-400 text-zinc-950 font-bold'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/60'
            }`}
          >
            <Lock className="h-3.5 w-3.5" />
            <span>Security &amp; Stealth PIN</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">

          {/* TAB 0: EDIT COVER PAGE & HERO */}
          {adminActiveTab === 'COVER' && (
            <form onSubmit={handleSaveCoverSettings} className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    <LayoutTemplate className="h-4 w-4 text-amber-400" />
                    <span>Edit Cover Page &amp; Hero Banner</span>
                  </h4>
                  <p className="text-xs text-zinc-400 mt-0.5">
                    Customize your homepage marquee cover photo, main headlines, and trust metrics.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    resetHeroSettings();
                    setCoverImageInput('/src/assets/images/hero_reel_creator_1791705571989.jpg');
                    setCoverHeadlineInput('Book an iPhone Reel Creator for Marriage & Delivery Events');
                    setCoverSubheadlineInput('Don’t let your wedding emotions or showroom car and bike delivery vanish into boring traditional video edits. Book dedicated iPhone 16 Pro creators with motorized gimbals, crisp wireless audio, and viral 24-hour delivery.');
                    setCoverBadgeInput('Cinematic Mobile Videography On Demand');
                    setCoverPrimaryCtaInput('Select Event & Book Date');
                    setCoverSecondaryCtaInput('Instant UPI & QR Advance Locking');
                    setCoverCameraSpecInput('iPhone 16 Pro Max · DJI Osmo Gimbal · Rode Wireless Mic');
                    setCoverEventsCountInput('500+ Events Filmed');
                    setCoverRatingInput('4.9 / 5.0 Rating');
                    setCoverTurnaroundInput('AirDrop Raw B-Roll Ready');
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-950 border border-zinc-800 text-xs text-zinc-400 hover:text-white cursor-pointer transition-colors shrink-0"
                >
                  <RotateCcw className="h-3.5 w-3.5" />
                  <span>Reset Cover to Default</span>
                </button>
              </div>

              {coverSavedMsg && (
                <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center gap-2">
                  <Check className="h-4 w-4 shrink-0" />
                  <span>Cover page updated successfully! Visible on homepage.</span>
                </div>
              )}

              {/* Cover Photo Settings & Live Preview */}
              <div className="p-5 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-4">
                <h5 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <ImageIcon className="h-4 w-4 text-amber-400" />
                  <span>1. Marquee Cover Photo</span>
                </h5>

                <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-center">
                  {/* Photo Preview */}
                  <div className="md:col-span-5">
                    <div className="relative rounded-xl overflow-hidden border border-zinc-700 bg-zinc-900 aspect-[16/10] shadow-md group">
                      <img
                        src={coverImageInput}
                        alt="Cover Preview"
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                      <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between text-[11px] text-white">
                        <span className="font-semibold truncate">Current Cover</span>
                        <span className="font-mono text-amber-400 text-[10px]">Active</span>
                      </div>
                    </div>
                  </div>

                  {/* Photo Controls */}
                  <div className="md:col-span-7 space-y-3">
                    <div>
                      <label className="block text-xs font-medium text-zinc-300 mb-1.5">
                        Upload Custom Photo from Your Device
                      </label>
                      <div className="flex items-center gap-3">
                        <label className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-zinc-900 border border-zinc-700 text-xs text-white hover:border-amber-400 cursor-pointer transition-colors">
                          <Upload className="h-4 w-4 text-amber-400" />
                          <span>Choose Image File (JPG/PNG)</span>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={handleCoverImageUpload}
                            className="hidden"
                          />
                        </label>
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-zinc-300 mb-1">
                        Or Image URL
                      </label>
                      <input
                        type="text"
                        placeholder="https://example.com/cover.jpg"
                        value={coverImageInput}
                        onChange={(e) => setCoverImageInput(e.target.value)}
                        className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white font-mono"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                        Or Pick from Cinematic Presets:
                      </label>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                        <button
                          type="button"
                          onClick={() => setCoverImageInput('/src/assets/images/hero_reel_creator_1791705571989.jpg')}
                          className={`p-1.5 rounded-lg border text-left text-[11px] transition-all cursor-pointer ${
                            coverImageInput === '/src/assets/images/hero_reel_creator_1791705571989.jpg'
                              ? 'border-amber-400 bg-amber-400/10 text-white font-semibold'
                              : 'border-zinc-800 bg-zinc-900/60 text-zinc-400 hover:border-zinc-700'
                          }`}
                        >
                          Filmmaker Rig
                        </button>

                        <button
                          type="button"
                          onClick={() => setCoverImageInput('/src/assets/images/marriage_reel_event_1791705584070.jpg')}
                          className={`p-1.5 rounded-lg border text-left text-[11px] transition-all cursor-pointer ${
                            coverImageInput === '/src/assets/images/marriage_reel_event_1791705584070.jpg'
                              ? 'border-amber-400 bg-amber-400/10 text-white font-semibold'
                              : 'border-zinc-800 bg-zinc-900/60 text-zinc-400 hover:border-zinc-700'
                          }`}
                        >
                          Wedding Haldi
                        </button>

                        <button
                          type="button"
                          onClick={() => setCoverImageInput('/src/assets/images/vehicle_delivery_event_1791705596887.jpg')}
                          className={`p-1.5 rounded-lg border text-left text-[11px] transition-all cursor-pointer ${
                            coverImageInput === '/src/assets/images/vehicle_delivery_event_1791705596887.jpg'
                              ? 'border-amber-400 bg-amber-400/10 text-white font-semibold'
                              : 'border-zinc-800 bg-zinc-900/60 text-zinc-400 hover:border-zinc-700'
                          }`}
                        >
                          Car Delivery
                        </button>

                        <button
                          type="button"
                          onClick={() => setCoverImageInput('/src/assets/images/party_event_reel_1791705607944.jpg')}
                          className={`p-1.5 rounded-lg border text-left text-[11px] transition-all cursor-pointer ${
                            coverImageInput === '/src/assets/images/party_event_reel_1791705607944.jpg'
                              ? 'border-amber-400 bg-amber-400/10 text-white font-semibold'
                              : 'border-zinc-800 bg-zinc-900/60 text-zinc-400 hover:border-zinc-700'
                          }`}
                        >
                          Nightclub Party
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Cover Headlines & Copy Text */}
              <div className="p-5 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-4">
                <h5 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <Edit2 className="h-4 w-4 text-amber-400" />
                  <span>2. Hero Headlines &amp; Storytelling Text</span>
                </h5>

                <div>
                  <label className="block text-xs font-semibold text-zinc-300 mb-1">
                    Top Kicker / Category Badge Text
                  </label>
                  <input
                    type="text"
                    required
                    value={coverBadgeInput}
                    onChange={(e) => setCoverBadgeInput(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl bg-zinc-900 border border-zinc-700 text-xs text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-zinc-300 mb-1">
                    Main Hero Headline (Title) *
                  </label>
                  <input
                    type="text"
                    required
                    value={coverHeadlineInput}
                    onChange={(e) => setCoverHeadlineInput(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl bg-zinc-900 border border-zinc-700 text-sm font-bold text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-zinc-300 mb-1">
                    Subheadline Paragraph (Description) *
                  </label>
                  <textarea
                    rows={3}
                    required
                    value={coverSubheadlineInput}
                    onChange={(e) => setCoverSubheadlineInput(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl bg-zinc-900 border border-zinc-700 text-xs text-white leading-relaxed"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-zinc-300 mb-1">
                      Primary CTA Button Label
                    </label>
                    <input
                      type="text"
                      required
                      value={coverPrimaryCtaInput}
                      onChange={(e) => setCoverPrimaryCtaInput(e.target.value)}
                      className="w-full px-3.5 py-2 rounded-xl bg-zinc-900 border border-zinc-700 text-xs text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-zinc-300 mb-1">
                      Secondary Badge / Payment Note
                    </label>
                    <input
                      type="text"
                      required
                      value={coverSecondaryCtaInput}
                      onChange={(e) => setCoverSecondaryCtaInput(e.target.value)}
                      className="w-full px-3.5 py-2 rounded-xl bg-zinc-900 border border-zinc-700 text-xs text-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-zinc-300 mb-1">
                    Camera &amp; Rig Spec Label (Under Viewfinder)
                  </label>
                  <input
                    type="text"
                    required
                    value={coverCameraSpecInput}
                    onChange={(e) => setCoverCameraSpecInput(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl bg-zinc-900 border border-zinc-700 text-xs text-white font-mono"
                  />
                </div>
              </div>

              {/* Trust Metrics */}
              <div className="p-5 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-4">
                <h5 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <Check className="h-4 w-4 text-amber-400" />
                  <span>3. Trust Strip Metrics (Under Hero)</span>
                </h5>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[11px] text-zinc-400 mb-1">Stat Metric 1</label>
                    <input
                      type="text"
                      value={coverEventsCountInput}
                      onChange={(e) => setCoverEventsCountInput(e.target.value)}
                      className="w-full px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] text-zinc-400 mb-1">Stat Metric 2</label>
                    <input
                      type="text"
                      value={coverRatingInput}
                      onChange={(e) => setCoverRatingInput(e.target.value)}
                      className="w-full px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] text-zinc-400 mb-1">Stat Metric 3</label>
                    <input
                      type="text"
                      value={coverTurnaroundInput}
                      onChange={(e) => setCoverTurnaroundInput(e.target.value)}
                      className="w-full px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white"
                    />
                  </div>
                </div>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  className="px-6 py-3 text-xs font-bold text-zinc-950 bg-amber-400 rounded-xl hover:bg-amber-300 transition-all cursor-pointer shadow-md shadow-amber-500/20"
                >
                  Save Cover Page Changes Live
                </button>
              </div>
            </form>
          )}

          {/* TAB 1: EVENT TABS & CATEGORIES */}
          {adminActiveTab === 'TABS' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h4 className="text-sm font-bold text-white">Event Categories / Tabs</h4>
                  <p className="text-xs text-zinc-400">
                    Add new event tabs or modify existing event descriptions and starting rates.
                  </p>
                </div>
                <button
                  onClick={() => setIsAddingCategory(true)}
                  className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-zinc-950 bg-amber-400 rounded-lg hover:bg-amber-300 transition-all cursor-pointer shrink-0"
                >
                  <Plus className="h-3.5 w-3.5" />
                  <span>Add New Event Tab</span>
                </button>
              </div>

              {/* Add category form modal / inline panel */}
              {isAddingCategory && (
                <form onSubmit={handleCreateCategory} className="p-4 rounded-xl bg-zinc-950 border border-zinc-700 space-y-4">
                  <div className="flex items-center justify-between">
                    <h5 className="text-xs font-bold text-amber-400 uppercase tracking-wider">
                      Create New Event Tab
                    </h5>
                    <button
                      type="button"
                      onClick={() => setIsAddingCategory(false)}
                      className="text-zinc-500 hover:text-white text-xs cursor-pointer"
                    >
                      Cancel
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs text-zinc-300 font-semibold mb-1">Tab Title *</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Corporate / Brand Launch, Pre-Wedding, Club Night"
                        value={newCatName}
                        onChange={(e) => setNewCatName(e.target.value)}
                        className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-zinc-300 font-semibold mb-1">Starting Base Price (₹) *</label>
                      <input
                        type="number"
                        required
                        value={newCatBasePrice}
                        onChange={(e) => setNewCatBasePrice(Number(e.target.value))}
                        className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs text-zinc-300 font-semibold mb-1">Short Tagline *</label>
                    <input
                      type="text"
                      placeholder="e.g. Dynamic showroom unveil, cinematic reels for new store launches"
                      value={newCatTagline}
                      onChange={(e) => setNewCatTagline(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs text-zinc-300 font-semibold mb-1">Full Description</label>
                    <textarea
                      rows={2}
                      placeholder="Detailed overview for the customer..."
                      value={newCatDescription}
                      onChange={(e) => setNewCatDescription(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs text-zinc-300 font-semibold mb-1">Icon Style</label>
                      <select
                        value={newCatIcon}
                        onChange={(e) => setNewCatIcon(e.target.value)}
                        className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white cursor-pointer"
                      >
                        <option value="Camera">Camera</option>
                        <option value="HeartHandshake">Wedding / Heart</option>
                        <option value="Car">Car / Vehicle</option>
                        <option value="PartyPopper">Party / Celebration</option>
                        <option value="Music">Music / Concert</option>
                        <option value="Sparkles">Sparkles / Luxury</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs text-zinc-300 font-semibold mb-1">Cover Image</label>
                      <select
                        value={newCatImage}
                        onChange={(e) => setNewCatImage(e.target.value)}
                        className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white cursor-pointer"
                      >
                        <option value="/src/assets/images/hero_reel_creator_1791705571989.jpg">Pro iPhone Creator Rig</option>
                        <option value="/src/assets/images/marriage_reel_event_1791705584070.jpg">Wedding Celebration</option>
                        <option value="/src/assets/images/vehicle_delivery_event_1791705596887.jpg">Vehicle Showroom Delivery</option>
                        <option value="/src/assets/images/party_event_reel_1791705607944.jpg">Nightlife &amp; Party Sparklers</option>
                      </select>
                    </div>
                  </div>

                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      type="submit"
                      className="px-4 py-2 text-xs font-bold text-zinc-950 bg-amber-400 rounded-lg hover:bg-amber-300 cursor-pointer"
                    >
                      Save &amp; Publish Tab
                    </button>
                  </div>
                </form>
              )}

              {/* Categories List */}
              <div className="space-y-3">
                {categories.map((cat) => (
                  <div
                    key={cat.id}
                    className="p-4 rounded-xl border border-zinc-800 bg-zinc-950/60 flex flex-col md:flex-row md:items-center justify-between gap-4"
                  >
                    {editingCatId === cat.id ? (
                      <div className="w-full space-y-3">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <input
                            type="text"
                            value={editCatName}
                            onChange={(e) => setEditCatName(e.target.value)}
                            className="px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white"
                          />
                          <input
                            type="number"
                            value={editCatBasePrice}
                            onChange={(e) => setEditCatBasePrice(Number(e.target.value))}
                            className="px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white"
                          />
                        </div>
                        <input
                          type="text"
                          value={editCatTagline}
                          onChange={(e) => setEditCatTagline(e.target.value)}
                          className="w-full px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white"
                        />
                        <textarea
                          rows={2}
                          value={editCatDescription}
                          onChange={(e) => setEditCatDescription(e.target.value)}
                          className="w-full px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white"
                        />
                        <div className="flex justify-end gap-2">
                          <button
                            onClick={() => setEditingCatId(null)}
                            className="px-3 py-1 text-xs text-zinc-400 hover:text-white"
                          >
                            Cancel
                          </button>
                          <button
                            onClick={() => handleSaveEditCategory(cat.id)}
                            className="px-3 py-1 text-xs font-bold text-zinc-950 bg-amber-400 rounded-lg hover:bg-amber-300"
                          >
                            Save Changes
                          </button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <div className="flex items-start gap-3">
                          <img
                            src={cat.coverImage}
                            alt={cat.name}
                            className="w-16 h-16 rounded-lg object-cover shrink-0 border border-zinc-700/60"
                          />
                          <div>
                            <div className="flex items-center gap-2">
                              <h5 className="text-sm font-bold text-white">{cat.name}</h5>
                              {cat.isCustom && (
                                <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-400/10 text-amber-400 border border-amber-400/20 font-mono">
                                  Custom Tab
                                </span>
                              )}
                            </div>
                            <p className="text-xs text-zinc-400 mt-0.5">{cat.tagline}</p>
                            <p className="text-xs text-amber-400 mt-1 font-semibold">
                              Base Price: {formatCurrency(cat.basePrice, paymentSettings.currencySymbol)} · {cat.packages.length} Packages
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <button
                            onClick={() => handleStartEditCategory(cat)}
                            className="p-2 text-zinc-400 hover:text-amber-400 hover:bg-zinc-800 rounded-lg transition-colors cursor-pointer"
                            title="Edit Category Details"
                          >
                            <Edit2 className="h-4 w-4" />
                          </button>
                          {categories.length > 1 && (
                            <button
                              onClick={() => deleteCategory(cat.id)}
                              className="p-2 text-zinc-500 hover:text-red-400 hover:bg-zinc-800 rounded-lg transition-colors cursor-pointer"
                              title="Delete Category"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          )}
                        </div>
                      </>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 2: EDIT PRICES & PACKAGES */}
          {adminActiveTab === 'PRICES' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h4 className="text-sm font-bold text-white">Edit Package Prices &amp; Text</h4>
                  <p className="text-xs text-zinc-400">
                    Change prices, turnaround hours, reel count, and feature inclusions for any category.
                  </p>
                </div>
                
                <div className="flex items-center gap-3">
                  <select
                    value={selectedCatForPackages}
                    onChange={(e) => setSelectedCatForPackages(e.target.value)}
                    className="px-3 py-2 rounded-lg bg-zinc-950 border border-zinc-700 text-xs text-white font-semibold cursor-pointer"
                  >
                    {categories.map(c => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>

                  <button
                    onClick={() => setIsAddingPkg(true)}
                    className="flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-zinc-950 bg-amber-400 rounded-lg hover:bg-amber-300 transition-all cursor-pointer whitespace-nowrap"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    <span>Add Package</span>
                  </button>
                </div>
              </div>

              {/* Add Package Form */}
              {isAddingPkg && (
                <form onSubmit={handleCreatePackage} className="p-4 rounded-xl bg-zinc-950 border border-zinc-700 space-y-4">
                  <div className="flex items-center justify-between">
                    <h5 className="text-xs font-bold text-amber-400 uppercase tracking-wider">
                      Add New Package to {currentCategoryForPackages?.name}
                    </h5>
                    <button
                      type="button"
                      onClick={() => setIsAddingPkg(false)}
                      className="text-zinc-500 hover:text-white text-xs cursor-pointer"
                    >
                      Cancel
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                    <div>
                      <label className="block text-xs text-zinc-300 font-semibold mb-1">Package Name *</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Cinematic Highlights"
                        value={newPkgName}
                        onChange={(e) => setNewPkgName(e.target.value)}
                        className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-zinc-300 font-semibold mb-1">Price (₹) *</label>
                      <input
                        type="number"
                        required
                        value={newPkgPrice}
                        onChange={(e) => setNewPkgPrice(Number(e.target.value))}
                        className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-zinc-300 font-semibold mb-1">Reels Count *</label>
                      <input
                        type="number"
                        required
                        value={newPkgReels}
                        onChange={(e) => setNewPkgReels(Number(e.target.value))}
                        className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-zinc-300 font-semibold mb-1">Turnaround (Hrs) *</label>
                      <input
                        type="number"
                        required
                        value={newPkgTurnaround}
                        onChange={(e) => setNewPkgTurnaround(Number(e.target.value))}
                        className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs text-zinc-300 font-semibold mb-1">
                      Features List (One bullet point per line)
                    </label>
                    <textarea
                      rows={3}
                      value={newPkgFeaturesText}
                      onChange={(e) => setNewPkgFeaturesText(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white font-mono"
                    />
                  </div>

                  <div className="flex justify-end gap-2">
                    <button
                      type="submit"
                      className="px-4 py-2 text-xs font-bold text-zinc-950 bg-amber-400 rounded-lg hover:bg-amber-300 cursor-pointer"
                    >
                      Save Package
                    </button>
                  </div>
                </form>
              )}

              {/* Current Category Packages */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {currentCategoryForPackages?.packages.map((pkg) => (
                  <div
                    key={pkg.id}
                    className="p-4 rounded-xl border border-zinc-800 bg-zinc-950/70 space-y-3"
                  >
                    {editingPkgId === pkg.id ? (
                      <div className="space-y-3">
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label className="text-[11px] text-zinc-400">Package Name</label>
                            <input
                              type="text"
                              value={pkgEditName}
                              onChange={(e) => setPkgEditName(e.target.value)}
                              className="w-full px-2.5 py-1.5 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white"
                            />
                          </div>
                          <div>
                            <label className="text-[11px] text-zinc-400">Price (₹)</label>
                            <input
                              type="number"
                              value={pkgEditPrice}
                              onChange={(e) => setPkgEditPrice(Number(e.target.value))}
                              className="w-full px-2.5 py-1.5 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white font-bold"
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-3 gap-2">
                          <div>
                            <label className="text-[11px] text-zinc-400">Reels</label>
                            <input
                              type="number"
                              value={pkgEditReels}
                              onChange={(e) => setPkgEditReels(Number(e.target.value))}
                              className="w-full px-2.5 py-1.5 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white"
                            />
                          </div>
                          <div>
                            <label className="text-[11px] text-zinc-400">Shoot Hours</label>
                            <input
                              type="number"
                              value={pkgEditDuration}
                              onChange={(e) => setPkgEditDuration(Number(e.target.value))}
                              className="w-full px-2.5 py-1.5 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white"
                            />
                          </div>
                          <div>
                            <label className="text-[11px] text-zinc-400">Delivery (Hrs)</label>
                            <input
                              type="number"
                              value={pkgEditTurnaround}
                              onChange={(e) => setPkgEditTurnaround(Number(e.target.value))}
                              className="w-full px-2.5 py-1.5 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="text-[11px] text-zinc-400">Features (1 per line)</label>
                          <textarea
                            rows={3}
                            value={pkgEditFeaturesText}
                            onChange={(e) => setPkgEditFeaturesText(e.target.value)}
                            className="w-full px-2.5 py-1.5 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white font-mono"
                          />
                        </div>

                        <div className="flex justify-end gap-2 pt-1">
                          <button
                            type="button"
                            onClick={() => setEditingPkgId(null)}
                            className="px-3 py-1 text-xs text-zinc-400 hover:text-white"
                          >
                            Cancel
                          </button>
                          <button
                            type="button"
                            onClick={() => handleSavePackage(currentCategoryForPackages.id, pkg.id)}
                            className="px-3 py-1 text-xs font-bold text-zinc-950 bg-amber-400 rounded-lg hover:bg-amber-300"
                          >
                            Save
                          </button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <div className="flex items-start justify-between">
                          <div>
                            <h5 className="text-sm font-bold text-white">{pkg.name}</h5>
                            <p className="text-lg font-black text-amber-400 tabular-nums">
                              {formatCurrency(pkg.price, paymentSettings.currencySymbol)}
                            </p>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <button
                              onClick={() => handleStartEditPackage(pkg)}
                              className="p-1.5 text-zinc-400 hover:text-amber-400 hover:bg-zinc-800 rounded-lg"
                              title="Edit Package"
                            >
                              <Edit2 className="h-3.5 w-3.5" />
                            </button>
                            {currentCategoryForPackages.packages.length > 1 && (
                              <button
                                onClick={() => deletePackage(currentCategoryForPackages.id, pkg.id)}
                                className="p-1.5 text-zinc-500 hover:text-red-400 hover:bg-zinc-800 rounded-lg"
                                title="Delete Package"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </button>
                            )}
                          </div>
                        </div>

                        <div className="text-xs text-zinc-400 flex items-center gap-2">
                          <span>{pkg.reelsCount} Reels</span>
                          <span aria-hidden="true">·</span>
                          <span>{pkg.durationHours}h Shoot</span>
                          <span aria-hidden="true">·</span>
                          <span className="text-emerald-400">{pkg.turnaroundHours}h Delivery</span>
                        </div>

                        <ul className="text-xs text-zinc-400 space-y-1 pt-2 border-t border-zinc-800">
                          {pkg.features.map((f, i) => (
                            <li key={i} className="flex items-center gap-2">
                              <span className="h-1 w-1 rounded-full bg-amber-400" />
                              <span className="truncate">{f}</span>
                            </li>
                          ))}
                        </ul>
                      </>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: UPI ID & QR SETTINGS */}
          {adminActiveTab === 'PAYMENTS' && (
            <form onSubmit={handleSavePayments} className="space-y-6 max-w-2xl">
              <div>
                <h4 className="text-sm font-bold text-white">Payment Gateway &amp; UPI Configuration</h4>
                <p className="text-xs text-zinc-400">
                  Customers will scan this QR or pay to this UPI ID when locking their shoot slot.
                </p>
              </div>

              {paymentSavedMessage && (
                <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center gap-2">
                  <Check className="h-4 w-4" />
                  <span>Payment details and QR settings updated successfully!</span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-zinc-300 mb-1">
                    Your UPI ID *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. reelsquad@okhdfcbank"
                    value={upiIdInput}
                    onChange={(e) => setUpiIdInput(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-700 text-sm font-mono text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-zinc-300 mb-1">
                    Payee Name / Studio Brand Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. ReelCraft Studio"
                    value={payeeNameInput}
                    onChange={(e) => setPayeeNameInput(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-700 text-sm text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 space-y-4">
                <label className="block text-xs font-semibold text-zinc-300">
                  Payment QR Code Delivery Method
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setQrTypeInput('dynamic')}
                    className={`p-3 rounded-lg border text-left cursor-pointer transition-all ${
                      qrTypeInput === 'dynamic'
                        ? 'border-amber-400 bg-amber-400/10 text-white font-bold'
                        : 'border-zinc-800 bg-zinc-900/50 text-zinc-400 hover:border-zinc-700'
                    }`}
                  >
                    <div className="text-xs font-bold text-amber-400">Auto Dynamic QR (Recommended)</div>
                    <div className="text-[11px] text-zinc-400 mt-1">
                      Instantly generates real QR with the exact client payable amount pre-filled.
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setQrTypeInput('custom_image')}
                    className={`p-3 rounded-lg border text-left cursor-pointer transition-all ${
                      qrTypeInput === 'custom_image'
                        ? 'border-amber-400 bg-amber-400/10 text-white font-bold'
                        : 'border-zinc-800 bg-zinc-900/50 text-zinc-400 hover:border-zinc-700'
                    }`}
                  >
                    <div className="text-xs font-bold text-zinc-300">Custom Uploaded QR Image</div>
                    <div className="text-[11px] text-zinc-400 mt-1">
                      Upload your shop/standee GPay/PhonePe merchant QR image.
                    </div>
                  </button>
                </div>

                {qrTypeInput === 'custom_image' && (
                  <div className="space-y-3 pt-2 border-t border-zinc-800">
                    <label className="block text-xs text-zinc-300 font-medium">
                      Upload Your QR Code Image
                    </label>
                    <div className="flex items-center gap-4">
                      <label className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-zinc-900 border border-zinc-700 text-xs text-white hover:border-amber-400 cursor-pointer transition-colors">
                        <Upload className="h-4 w-4 text-amber-400" />
                        <span>Upload QR File</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleCustomQrFileUpload}
                          className="hidden"
                        />
                      </label>
                      {customQrImageInput && (
                        <div className="flex items-center gap-2 text-xs text-emerald-400">
                          <Check className="h-4 w-4" />
                          <span>QR Image loaded ({customQrImageInput.slice(0, 20)}...)</span>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-zinc-300 mb-1">
                    Advance Deposit Percentage (%)
                  </label>
                  <input
                    type="number"
                    min={10}
                    max={100}
                    value={advancePercentInput}
                    onChange={(e) => setAdvancePercentInput(Number(e.target.value))}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-700 text-sm text-white focus:outline-none focus:border-amber-400"
                  />
                  <p className="text-[11px] text-zinc-500 mt-1">
                    Usually 30% or 50% to reserve creator date.
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-zinc-300 mb-1">
                    Support WhatsApp / Call Number
                  </label>
                  <input
                    type="tel"
                    value={supportPhoneInput}
                    onChange={(e) => setSupportPhoneInput(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-700 text-sm text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1">
                  Payment Instructions Note to Customer
                </label>
                <textarea
                  rows={2}
                  value={paymentNoteInput}
                  onChange={(e) => setPaymentNoteInput(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-zinc-950 border border-zinc-700 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="px-6 py-2.5 text-xs font-bold text-zinc-950 bg-amber-400 rounded-xl hover:bg-amber-300 transition-all cursor-pointer shadow-md shadow-amber-500/20"
                >
                  Save Payment &amp; QR Settings
                </button>
              </div>
            </form>
          )}

          {/* TAB 4: CLIENT BOOKINGS */}
          {adminActiveTab === 'BOOKINGS' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-white">All Client Bookings</h4>
                  <p className="text-xs text-zinc-400">
                    Verify client UPI payments, view UTR reference numbers, and manage shooting schedules.
                  </p>
                </div>

                <button
                  onClick={resetAllData}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-zinc-400 hover:text-white bg-zinc-950 border border-zinc-800 rounded-lg hover:border-zinc-700 transition-colors cursor-pointer"
                  title="Reset all categories and test bookings back to initial defaults"
                >
                  <RotateCcw className="h-3.5 w-3.5" />
                  <span>Reset Demo Data</span>
                </button>
              </div>

              {bookings.length === 0 ? (
                <div className="p-8 text-center rounded-xl bg-zinc-950 border border-zinc-800 text-zinc-500 text-xs">
                  No bookings yet. Customer orders will show up here in real time.
                </div>
              ) : (
                <div className="space-y-4">
                  {bookings.map((booking: Booking) => (
                    <div
                      key={booking.id}
                      className="p-5 rounded-2xl border border-zinc-800 bg-zinc-950/80 space-y-4"
                    >
                      {/* Top Bar of booking card */}
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-zinc-800">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-sm font-bold text-amber-400">{booking.id}</span>
                          <span className="text-zinc-600">·</span>
                          <span className="text-xs font-medium text-white">{booking.categoryName}</span>
                          <span className="text-zinc-600">·</span>
                          <span className="text-xs text-zinc-400">{booking.packageName}</span>
                        </div>

                        <div className="flex items-center gap-2">
                          <span
                            className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
                              booking.paymentStatus === 'VERIFIED'
                                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                                : booking.paymentStatus === 'PENDING_VERIFICATION'
                                ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                                : 'bg-zinc-800 text-zinc-400'
                            }`}
                          >
                            {booking.paymentStatus === 'VERIFIED' ? 'Payment Verified' : 'Pending Verification'}
                          </span>
                        </div>
                      </div>

                      {/* Details Grid */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-xs">
                        <div>
                          <span className="text-zinc-500">Client Contact</span>
                          <p className="font-semibold text-white mt-0.5">{booking.clientName}</p>
                          <p className="text-zinc-400">{booking.clientPhone}</p>
                          {booking.instagramHandle && (
                            <p className="text-amber-400/90 font-mono text-[11px]">{booking.instagramHandle}</p>
                          )}
                        </div>

                        <div>
                          <span className="text-zinc-500">Schedule &amp; Venue</span>
                          <p className="font-semibold text-white mt-0.5">
                            {booking.eventDate} at {booking.startTime}
                          </p>
                          <p className="text-zinc-400 truncate">{booking.venueLocation}</p>
                        </div>

                        <div>
                          <span className="text-zinc-500">Payment Breakdown</span>
                          <p className="font-semibold text-emerald-400 mt-0.5">
                            {formatCurrency(booking.advancePaid, paymentSettings.currencySymbol)} ({booking.paymentMode})
                          </p>
                          <p className="text-[11px] font-mono text-zinc-400 truncate">
                            UTR: {booking.transactionId}
                          </p>
                        </div>

                        <div>
                          <span className="text-zinc-500">Aesthetic Vibe</span>
                          <p className="text-zinc-300 mt-0.5 truncate">{booking.musicAestheticVibe}</p>
                          {booking.specialInstructions && (
                            <p className="text-zinc-500 text-[11px] truncate mt-0.5">
                              Note: {booking.specialInstructions}
                            </p>
                          )}
                        </div>
                      </div>

                      {/* Action buttons */}
                      <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-zinc-800/80">
                        <div className="flex items-center gap-2">
                          {booking.paymentReceiptUrl && (
                            <button
                              onClick={() => setPreviewReceiptUrl(booking.paymentReceiptUrl || null)}
                              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-zinc-300 hover:text-white cursor-pointer"
                            >
                              <Eye className="h-3.5 w-3.5 text-amber-400" />
                              <span>View Receipt Screenshot</span>
                            </button>
                          )}

                          <a
                            href={`https://wa.me/${booking.clientPhone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(`Hi ${booking.clientName}! This is your ReelCraft creator for ${booking.eventDate}. Regarding your booking ${booking.id}...`)}`}
                            target="_blank"
                            rel="noreferrer"
                            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600/20 border border-emerald-600/40 text-xs font-semibold text-emerald-400 hover:bg-emerald-600/30 cursor-pointer"
                          >
                            <MessageSquare className="h-3.5 w-3.5" />
                            <span>WhatsApp Client</span>
                          </a>
                        </div>

                        <div className="flex items-center gap-2">
                          {booking.paymentStatus === 'PENDING_VERIFICATION' ? (
                            <button
                              onClick={() => updateBookingStatus(booking.id, 'VERIFIED')}
                              className="px-3 py-1.5 text-xs font-bold text-zinc-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors cursor-pointer"
                            >
                              Verify Payment UTR
                            </button>
                          ) : (
                            <span className="text-xs text-emerald-400 flex items-center gap-1 font-semibold">
                              <Check className="h-3.5 w-3.5" />
                              Payment Confirmed
                            </span>
                          )}

                          <button
                            onClick={() => deleteBooking(booking.id)}
                            className="p-1.5 text-zinc-600 hover:text-red-400 transition-colors cursor-pointer"
                            title="Delete Booking"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 5: CREATOR APPLICATIONS */}
          {adminActiveTab === 'APPLICATIONS' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    <Camera className="h-4 w-4 text-amber-400" />
                    <span>Creator Onboarding Applications ({creatorApplications.length})</span>
                  </h4>
                  <p className="text-xs text-zinc-400">
                    Review videographers who applied to shoot for Reelmate, verify phone models &amp; gear setup photos, and approve or reject.
                  </p>
                </div>

                <div className="flex items-center gap-1.5 p-1 rounded-xl bg-zinc-950 border border-zinc-800 text-xs">
                  {(['ALL', 'PENDING', 'APPROVED', 'REJECTED'] as const).map((filter) => {
                    const count = filter === 'ALL'
                      ? creatorApplications.length
                      : creatorApplications.filter(a => a.status === filter).length;
                    return (
                      <button
                        key={filter}
                        onClick={() => setApplicationFilter(filter)}
                        className={`px-3 py-1.5 rounded-lg font-semibold transition-colors cursor-pointer ${
                          applicationFilter === filter
                            ? 'bg-amber-400 text-zinc-950 font-bold'
                            : 'text-zinc-400 hover:text-white'
                        }`}
                      >
                        {filter === 'ALL' ? 'All' : filter === 'PENDING' ? 'Pending' : filter === 'APPROVED' ? 'Approved' : 'Rejected'} ({count})
                      </button>
                    );
                  })}
                </div>
              </div>

              {creatorApplications.length === 0 ? (
                <div className="p-12 text-center rounded-2xl bg-zinc-950 border border-zinc-800">
                  <Camera className="h-10 w-10 text-zinc-600 mx-auto mb-3" />
                  <p className="text-sm font-bold text-white">No creator applications yet</p>
                  <p className="text-xs text-zinc-500 mt-1 max-w-sm mx-auto">
                    When videographers click &quot;Become a Creator&quot; on the website and submit their iPhone and gimbal rig, their applications will show up here.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-4">
                  {creatorApplications
                    .filter(app => applicationFilter === 'ALL' || app.status === applicationFilter)
                    .map((app) => (
                      <div
                        key={app.id}
                        className="p-5 rounded-2xl bg-zinc-950 border border-zinc-800 hover:border-zinc-700 transition-all space-y-4"
                      >
                        {/* Top Applicant Row */}
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-zinc-850">
                          <div>
                            <div className="flex items-center gap-2.5">
                              <span className="font-extrabold text-white text-base">{app.fullName}</span>
                              <span
                                className={`text-[11px] font-bold px-2 py-0.5 rounded-full border ${
                                  app.status === 'APPROVED'
                                    ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-400'
                                    : app.status === 'REJECTED'
                                    ? 'bg-red-500/15 border-red-500/30 text-red-400'
                                    : 'bg-amber-500/15 border-amber-500/30 text-amber-400'
                                }`}
                              >
                                {app.status === 'APPROVED' ? 'Approved Creator' : app.status === 'REJECTED' ? 'Rejected' : 'Pending Review'}
                              </span>
                              <span className="text-[11px] font-mono text-zinc-500">{app.id}</span>
                            </div>
                            <div className="flex flex-wrap items-center gap-3 mt-1 text-xs text-zinc-400">
                              <span className="flex items-center gap-1">
                                <MapPin className="h-3.5 w-3.5 text-zinc-500" />
                                {app.city}
                              </span>
                              <span>·</span>
                              <span className="flex items-center gap-1">
                                <Phone className="h-3.5 w-3.5 text-zinc-500" />
                                {app.phone}
                              </span>
                              {app.email && (
                                <>
                                  <span>·</span>
                                  <span>{app.email}</span>
                                </>
                              )}
                              <span>·</span>
                              <span>Applied {new Date(app.appliedAt).toLocaleDateString()}</span>
                            </div>
                          </div>

                          <div className="flex items-center gap-2 shrink-0">
                            {/* WhatsApp Direct Chat */}
                            <a
                              href={`https://wa.me/${app.phone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(`Hi ${app.fullName}! This is Reelmate admin reviewing your creator application (${app.id}) with ${app.phoneModel}.`)}`}
                              target="_blank"
                              rel="noreferrer"
                              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600/20 border border-emerald-500/40 text-emerald-400 hover:bg-emerald-600/30 text-xs font-semibold cursor-pointer"
                            >
                              <MessageSquare className="h-3.5 w-3.5" />
                              <span>WhatsApp</span>
                            </a>

                            {/* Instagram link */}
                            {app.instagramHandle && (
                              <a
                                href={app.instagramHandle.startsWith('http') ? app.instagramHandle : `https://instagram.com/${app.instagramHandle.replace('@', '')}`}
                                target="_blank"
                                rel="noreferrer"
                                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-750 text-zinc-300 hover:text-white text-xs font-semibold"
                              >
                                <Instagram className="h-3.5 w-3.5 text-pink-400" />
                                <span>{app.instagramHandle}</span>
                                <ExternalLink className="h-3 w-3 text-zinc-500" />
                              </a>
                            )}
                          </div>
                        </div>

                        {/* Middle: Phone Fleet & Gear Hardware */}
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 rounded-xl bg-zinc-900/60 border border-zinc-800/80 text-xs">
                          {/* Col 1: Phone fleet & storage */}
                          <div className="space-y-1.5">
                            <span className="text-[11px] font-bold text-amber-400 uppercase tracking-wide flex items-center gap-1.5">
                              <Smartphone className="h-3.5 w-3.5" />
                              Phone Hardware
                            </span>
                            <p className="font-bold text-white text-sm">
                              {app.phoneModel} <span className="text-zinc-400 text-xs font-normal">({app.phoneStorage})</span>
                            </p>
                            {app.shootsProResLog && (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-amber-400/10 text-amber-300 border border-amber-400/20 text-[10px] font-semibold">
                                <Sparkles className="h-2.5 w-2.5" />
                                Apple ProRes 4K HDR Log Ready
                              </span>
                            )}
                            {app.secondaryPhone && (
                              <p className="text-[11px] text-zinc-400">
                                <span className="text-zinc-500">Backup Phone:</span> {app.secondaryPhone}
                              </p>
                            )}
                            {app.allPhonesList && app.allPhonesList.length > 0 && (
                              <div className="pt-1">
                                <span className="text-[10px] text-zinc-500">All Phones Owned:</span>
                                <div className="flex flex-wrap gap-1 mt-0.5">
                                  {app.allPhonesList.map((m) => (
                                    <span key={m} className="px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-300 text-[10px] font-mono">
                                      {m}
                                    </span>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>

                          {/* Col 2: Stabilizer & Audio */}
                          <div className="space-y-1.5">
                            <span className="text-[11px] font-bold text-amber-400 uppercase tracking-wide flex items-center gap-1.5">
                              <Sliders className="h-3.5 w-3.5" />
                              Stabilizer &amp; Audio Rig
                            </span>
                            <p className="text-zinc-200">
                              <strong className="text-white">Gimbal:</strong> {app.gimbalModel || 'Standard handheld'}
                            </p>
                            <p className="text-zinc-200">
                              <strong className="text-white">Mic:</strong> {app.micModel || 'Internal iPhone mic'}
                            </p>
                            {app.lightingAndAccessories && (
                              <p className="text-[11px] text-zinc-400">
                                <strong className="text-zinc-300">Accessories:</strong> {app.lightingAndAccessories}
                              </p>
                            )}
                          </div>

                          {/* Col 3: Experience & Rates */}
                          <div className="space-y-1.5">
                            <span className="text-[11px] font-bold text-amber-400 uppercase tracking-wide flex items-center gap-1.5">
                              <DollarSign className="h-3.5 w-3.5" />
                              Rates &amp; Experience
                            </span>
                            <p className="text-zinc-200">
                              <strong className="text-white">Expected Rate:</strong>{' '}
                              <span className="font-extrabold text-emerald-400 text-sm">
                                ₹{app.expectedRatePerShoot.toLocaleString('en-IN')}
                              </span>{' '}
                              <span className="text-zinc-500 text-[11px]">/ event</span>
                            </p>
                            <p className="text-zinc-300 text-[11px]">
                              {app.yearsOfExperience}
                            </p>
                            <div className="flex flex-wrap gap-1 mt-1">
                              {app.eventExperience.map(cat => (
                                <span key={cat} className="px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-400 text-[10px]">
                                  {cat}
                                </span>
                              ))}
                            </div>
                          </div>
                        </div>

                        {/* Bio / Portfolio link */}
                        {(app.bioNotes || app.portfolioUrl) && (
                          <div className="text-xs text-zinc-300 flex flex-wrap items-center justify-between gap-2 p-3 rounded-xl bg-zinc-900/40 border border-zinc-850">
                            {app.bioNotes && (
                              <p className="italic text-zinc-400">
                                &quot;{app.bioNotes}&quot;
                              </p>
                            )}
                            {app.portfolioUrl && (
                              <a
                                href={app.portfolioUrl}
                                target="_blank"
                                rel="noreferrer"
                                className="flex items-center gap-1 text-amber-400 hover:text-amber-300 font-semibold"
                              >
                                <span>View Reel Portfolio Drive</span>
                                <ExternalLink className="h-3 w-3" />
                              </a>
                            )}
                          </div>
                        )}

                        {/* Uploaded Photos Proofs */}
                        {(app.phonePhotoUrl || app.gearPhotoUrl) && (
                          <div className="flex flex-wrap items-center gap-4 pt-1">
                            {app.phonePhotoUrl && (
                              <div className="flex items-center gap-2">
                                <button
                                  type="button"
                                  onClick={() => setPreviewReceiptUrl(app.phonePhotoUrl!)}
                                  className="group relative rounded-lg overflow-hidden border border-zinc-700 w-16 h-16 hover:border-amber-400 transition-colors cursor-pointer"
                                >
                                  <img
                                    src={app.phonePhotoUrl}
                                    alt="Phone proof"
                                    className="w-full h-full object-cover"
                                  />
                                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center text-white">
                                    <Eye className="h-4 w-4" />
                                  </div>
                                </button>
                                <div>
                                  <span className="text-xs font-semibold text-zinc-200 block">Phone Verification</span>
                                  <span className="text-[11px] text-zinc-500">Click to enlarge</span>
                                </div>
                              </div>
                            )}

                            {app.gearPhotoUrl && (
                              <div className="flex items-center gap-2">
                                <button
                                  type="button"
                                  onClick={() => setPreviewReceiptUrl(app.gearPhotoUrl!)}
                                  className="group relative rounded-lg overflow-hidden border border-zinc-700 w-16 h-16 hover:border-amber-400 transition-colors cursor-pointer"
                                >
                                  <img
                                    src={app.gearPhotoUrl}
                                    alt="Gear setup proof"
                                    className="w-full h-full object-cover"
                                  />
                                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center text-white">
                                    <Eye className="h-4 w-4" />
                                  </div>
                                </button>
                                <div>
                                  <span className="text-xs font-semibold text-zinc-200 block">Gear Setup Proof</span>
                                  <span className="text-[11px] text-zinc-500">Click to enlarge</span>
                                </div>
                              </div>
                            )}
                          </div>
                        )}

                        {/* Admin Action Bar */}
                        <div className="flex items-center justify-between pt-3 border-t border-zinc-850">
                          <div className="flex items-center gap-2">
                            {app.status !== 'APPROVED' && (
                              <button
                                onClick={() => updateCreatorApplicationStatus(app.id, 'APPROVED')}
                                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-colors cursor-pointer"
                              >
                                <CheckCircle2 className="h-3.5 w-3.5" />
                                <span>Approve Creator</span>
                              </button>
                            )}

                            {app.status !== 'REJECTED' && (
                              <button
                                onClick={() => updateCreatorApplicationStatus(app.id, 'REJECTED')}
                                className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-semibold transition-colors cursor-pointer"
                              >
                                Reject
                              </button>
                            )}

                            {app.status !== 'PENDING' && (
                              <button
                                onClick={() => updateCreatorApplicationStatus(app.id, 'PENDING')}
                                className="px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-750 text-zinc-400 hover:text-white text-xs font-medium cursor-pointer"
                              >
                                Mark Pending
                              </button>
                            )}
                          </div>

                          <button
                            onClick={() => deleteCreatorApplication(app.id)}
                            className="p-1.5 text-zinc-600 hover:text-red-400 transition-colors cursor-pointer"
                            title="Delete application"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 6: ADMIN SECURITY & STEALTH PIN */}
          {adminActiveTab === 'SECURITY' && (
            <div className="space-y-6 max-w-2xl">
              <div>
                <h4 className="text-sm font-bold text-white flex items-center gap-2">
                  <Lock className="h-4 w-4 text-amber-400" />
                  <span>Admin Stealth Mode &amp; Master PIN Security</span>
                </h4>
                <p className="text-xs text-zinc-400 mt-0.5">
                  Protect your pricing, tabs, and booking management so only you can access them.
                </p>
              </div>

              {securitySavedMsg && (
                <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center gap-2">
                  <Check className="h-4 w-4 shrink-0" />
                  <span>Security and stealth preferences saved successfully!</span>
                </div>
              )}

              <form onSubmit={handleSaveSecuritySettings} className="space-y-5">
                {/* Stealth Mode Toggle */}
                <div className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 space-y-3">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <span className="text-xs font-bold text-white flex items-center gap-1.5">
                        <EyeOff className="h-3.5 w-3.5 text-amber-400" />
                        <span>Hide Admin Portal from Public Visitors</span>
                      </span>
                      <p className="text-[11px] text-zinc-400 mt-1 leading-relaxed">
                        When enabled, visitors will never see the &quot;Admin Portal&quot; button in the header, category sections, or footer. The site looks 100% customer-facing. Only you can unlock it using your secret shortcuts below.
                      </p>
                    </div>

                    <label className="relative inline-flex items-center cursor-pointer shrink-0 mt-1">
                      <input
                        type="checkbox"
                        checked={hidePublicInput}
                        onChange={(e) => setHidePublicInput(e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-zinc-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-zinc-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-400"></div>
                    </label>
                  </div>
                </div>

                {/* Master PIN configuration */}
                <div className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 space-y-3">
                  <div>
                    <label className="block text-xs font-bold text-white mb-1 flex items-center gap-1.5">
                      <Key className="h-3.5 w-3.5 text-amber-400" />
                      <span>Master Security PIN</span>
                    </label>
                    <p className="text-[11px] text-zinc-400 mb-2">
                      The secret code required to unlock the Admin Portal (Default is <span className="font-mono text-amber-400 font-bold">2026</span>).
                    </p>
                  </div>

                  <div className="flex gap-3">
                    <input
                      type="text"
                      required
                      placeholder="e.g. 2026 or secret code"
                      value={adminPinInput}
                      onChange={(e) => setAdminPinInput(e.target.value)}
                      className="px-3.5 py-2.5 rounded-xl bg-zinc-900 border border-zinc-700 text-sm font-mono text-white focus:outline-none focus:border-amber-400 max-w-xs"
                    />
                  </div>
                </div>

                <div className="pt-1">
                  <button
                    type="submit"
                    className="px-6 py-2.5 text-xs font-bold text-zinc-950 bg-amber-400 rounded-xl hover:bg-amber-300 transition-all cursor-pointer shadow-md shadow-amber-500/10"
                  >
                    Save Security Preferences
                  </button>
                </div>
              </form>

              {/* Secret Access Instructions Card */}
              <div className="p-4 rounded-xl bg-gradient-to-b from-zinc-950 to-zinc-900 border border-amber-500/20 space-y-3 text-xs">
                <div className="text-amber-400 font-bold flex items-center gap-1.5">
                  <Shield className="h-4 w-4" />
                  <span>How Only You Can Open the Admin Portal:</span>
                </div>

                <div className="space-y-2.5 text-zinc-300">
                  <div className="flex items-start gap-2.5">
                    <span className="font-bold text-amber-400 shrink-0">1.</span>
                    <div>
                      <strong className="text-white">Secret Keyboard Shortcut:</strong> Press{' '}
                      <kbd className="px-1.5 py-0.5 rounded bg-zinc-800 text-amber-300 font-mono text-[11px]">
                        Ctrl + Shift + A
                      </kbd>{' '}
                      (or <kbd className="px-1.5 py-0.5 rounded bg-zinc-800 text-amber-300 font-mono text-[11px]">Cmd + Shift + A</kbd> on Mac) from any page.
                    </div>
                  </div>

                  <div className="flex items-start gap-2.5">
                    <span className="font-bold text-amber-400 shrink-0">2.</span>
                    <div>
                      <strong className="text-white">Direct Secret URL:</strong> Bookmark your site with{' '}
                      <code className="text-amber-300 font-mono">#admin</code> at the end (e.g.{' '}
                      <span className="text-zinc-400">your-website-url.com/#admin</span>).
                    </div>
                  </div>

                  <div className="flex items-start gap-2.5">
                    <span className="font-bold text-amber-400 shrink-0">3.</span>
                    <div>
                      <strong className="text-white">Hidden Footer Lock:</strong> Scroll to the bottom footer and click the tiny lock icon next to the copyright text.
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-zinc-800 flex items-center justify-between">
                  <span className="text-[11px] text-zinc-500">Need to log out immediately?</span>
                  <button
                    type="button"
                    onClick={() => {
                      logoutAdmin();
                      closeAdminModal();
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 hover:bg-red-500/20 text-xs font-semibold cursor-pointer"
                  >
                    <LogOut className="h-3.5 w-3.5" />
                    <span>Log Out &amp; Lock Now</span>
                  </button>
                </div>
              </div>
            </div>
          )}

        </div>

      </div>

      {/* Screenshot Preview Modal */}
      {previewReceiptUrl && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/90">
          <div className="relative max-w-lg w-full bg-zinc-900 rounded-2xl border border-zinc-700 p-4">
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-zinc-800">
              <span className="text-xs font-bold text-white">Customer Payment Screenshot</span>
              <button
                onClick={() => setPreviewReceiptUrl(null)}
                className="text-zinc-400 hover:text-white"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <img
              src={previewReceiptUrl}
              alt="Payment proof receipt"
              className="w-full max-h-[70vh] object-contain rounded-lg"
            />
          </div>
        </div>
      )}

    </div>
  );
};
