import React, { useState } from 'react';
import { 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Heart, 
  Share2, 
  Sparkles, 
  CheckCircle, 
  Zap, 
  Sliders, 
  Flame 
} from 'lucide-react';

interface ShowcaseReel {
  id: string;
  category: string;
  title: string;
  views: string;
  likes: string;
  audioTrack: string;
  image: string;
  tag: string;
}

const SHOWCASE_REELS: ShowcaseReel[] = [
  {
    id: 'reel-1',
    category: 'Marriage Event',
    title: 'Emotional Varmala Garland Exchange in Golden Hour Glow',
    views: '482K',
    likes: '42.8K',
    audioTrack: 'O Maahi · Acoustic Slowed',
    image: '/src/assets/images/marriage_reel_event_1791705584070.jpg',
    tag: 'Trending Wedding Audio'
  },
  {
    id: 'reel-2',
    category: 'Supercar Delivery',
    title: 'Porsche GT3 RS Satin Drop & First Cold Start Exhaust',
    views: '890K',
    likes: '94.2K',
    audioTrack: 'After Dark X Sweater Weather',
    image: '/src/assets/images/vehicle_delivery_event_1791705596887.jpg',
    tag: 'Viral Automotive Beat'
  },
  {
    id: 'reel-3',
    category: 'Nightlife & Milestone',
    title: '25th Birthday Champagne Sparkler Fountain Drop',
    views: '310K',
    likes: '29.5K',
    audioTrack: 'Murder on the Dancefloor Club Mix',
    image: '/src/assets/images/party_event_reel_1791705607944.jpg',
    tag: 'High Energy Beat Sync'
  }
];

export const GearAndShowcaseSection: React.FC = () => {
  const [activePlayingId, setActivePlayingId] = useState<string | null>('reel-1');
  const [isMuted, setIsMuted] = useState(true);

  const togglePlay = (id: string) => {
    setActivePlayingId(prev => prev === id ? null : id);
  };

  return (
    <div className="space-y-24 bg-zinc-950 text-white">
      
      {/* SHOWCASE SECTION */}
      <section id="showcase" className="py-16 border-t border-zinc-900 scroll-mt-14">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
            <div>
              <div className="flex items-center gap-2 text-xs font-semibold text-amber-400 uppercase tracking-wider mb-2">
                <Flame className="h-3.5 w-3.5" />
                <span>Viral Aesthetic Showcase</span>
              </div>
              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold tracking-tight text-white text-balance">
                Real Reels Filmed &amp; Graded on iPhone 16 Pro Max
              </h2>
            </div>
            <p className="text-xs text-zinc-400 max-w-md">
              Over 4.5M combined views generated for our wedding couples and showroom delivery clients across Instagram and YouTube Shorts.
            </p>
          </div>

          {/* Vertical Reel Mockup Cards (3-column vertical grid) */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
            {SHOWCASE_REELS.map((reel) => {
              const isPlaying = activePlayingId === reel.id;

              return (
                <div
                  key={reel.id}
                  className="relative group rounded-3xl overflow-hidden border border-zinc-800 bg-zinc-900 shadow-xl transition-all hover:border-amber-500/50"
                >
                  {/* Aspect Ratio 9:16 vertical video container */}
                  <div className="relative aspect-[9/16] w-full overflow-hidden bg-zinc-950">
                    <img
                      src={reel.image}
                      alt={reel.title}
                      className={`w-full h-full object-cover transition-transform duration-700 ${
                        isPlaying ? 'scale-105 filter brightness-105' : 'group-hover:scale-102'
                      }`}
                      referrerPolicy="no-referrer"
                    />

                    {/* Gradient scrim for readable text */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-black/40" />

                    {/* Reel Top Bar: Live tag & sound indicator */}
                    <div className="absolute top-4 left-4 right-4 flex items-center justify-between text-xs text-white">
                      <span className="px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md border border-white/10 text-[11px] font-medium">
                        {reel.category}
                      </span>
                      <button
                        onClick={() => setIsMuted(!isMuted)}
                        className="p-2 rounded-full bg-black/60 backdrop-blur-md border border-white/10 text-white hover:bg-black/80 transition-colors cursor-pointer"
                        title={isMuted ? 'Unmute' : 'Mute'}
                      >
                        {isMuted ? <VolumeX className="h-3.5 w-3.5" /> : <Volume2 className="h-3.5 w-3.5 text-amber-400" />}
                      </button>
                    </div>

                    {/* Play / Pause Center Floating Trigger */}
                    <button
                      onClick={() => togglePlay(reel.id)}
                      className="absolute inset-0 flex items-center justify-center cursor-pointer group/btn"
                    >
                      <div className={`flex h-14 w-14 items-center justify-center rounded-full bg-black/60 backdrop-blur-md border border-white/20 text-white transition-all transform ${
                        isPlaying ? 'opacity-0 group-hover:opacity-100 scale-90' : 'opacity-90 scale-100 group-hover/btn:scale-110'
                      }`}>
                        {isPlaying ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6 fill-white ml-0.5" />}
                      </div>
                    </button>

                    {/* Instagram Metrics Right Rail */}
                    <div className="absolute right-4 bottom-24 flex flex-col items-center gap-4 text-white text-xs pointer-events-none">
                      <div className="flex flex-col items-center gap-1">
                        <div className="p-2 rounded-full bg-black/40 backdrop-blur-sm">
                          <Heart className="h-5 w-5 text-red-500 fill-red-500" />
                        </div>
                        <span className="text-[10px] font-bold">{reel.likes}</span>
                      </div>
                      <div className="flex flex-col items-center gap-1">
                        <div className="p-2 rounded-full bg-black/40 backdrop-blur-sm">
                          <Share2 className="h-5 w-5 text-white" />
                        </div>
                        <span className="text-[10px] font-bold">{reel.views}</span>
                      </div>
                    </div>

                    {/* Reel Bottom Meta */}
                    <div className="absolute bottom-4 left-4 right-16 space-y-2 pointer-events-none text-left">
                      <div className="text-[11px] font-semibold text-amber-400 flex items-center gap-1.5">
                        <Sparkles className="h-3 w-3" />
                        <span>{reel.tag}</span>
                      </div>
                      <p className="text-xs font-semibold text-white leading-snug line-clamp-2">
                        {reel.title}
                      </p>
                      <div className="flex items-center gap-2 text-[11px] text-zinc-300 font-mono">
                        <span className="animate-spin text-amber-400">♫</span>
                        <span className="truncate">{reel.audioTrack}</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

        </div>
      </section>

      {/* GEAR & CINEMATOGRAPHY ADVANTAGE */}
      <section id="quality" className="py-16 border-t border-zinc-900 scroll-mt-14">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          
          <div className="max-w-2xl mb-12">
            <div className="flex items-center gap-2 text-xs font-semibold text-amber-400 uppercase tracking-wider mb-2">
              <Sliders className="h-3.5 w-3.5" />
              <span>The iPhone Creator Advantage</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white text-balance">
              Why an iPhone Reel Creator Beats Bulky Wedding Camera Crews
            </h2>
            <p className="mt-3 text-xs sm:text-sm text-zinc-400 leading-relaxed">
              Traditional videographers take 2 to 3 months to deliver horizontal footage that doesn’t fit Instagram. Our mobile creators shoot native 9:16 vertical 4K, stay completely unobtrusive, and hand over raw footage the very same day.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 rounded-2xl border border-zinc-800 bg-zinc-900/50 space-y-3">
              <div className="h-10 w-10 rounded-xl bg-amber-400/10 border border-amber-400/20 text-amber-400 flex items-center justify-center font-bold">
                01
              </div>
              <h3 className="text-base font-bold text-white">Native Vertical 9:16 4K ProRes</h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Shot specifically for Instagram Reels, YouTube Shorts &amp; TikTok. No awkward side crops or quality loss from horizontal downscaling.
              </p>
              <div className="pt-2 text-xs text-zinc-300 font-mono">
                ✓ 4K 60fps ProRes Log · 10-Bit Color Depth
              </div>
            </div>

            <div className="p-6 rounded-2xl border border-zinc-800 bg-zinc-900/50 space-y-3">
              <div className="h-10 w-10 rounded-xl bg-amber-400/10 border border-amber-400/20 text-amber-400 flex items-center justify-center font-bold">
                02
              </div>
              <h3 className="text-base font-bold text-white">Ultra-Agile Gimbal &amp; Candid Access</h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                No massive cranes, bright blinding lights, or intimidating heavy rigs. We weave effortlessly into dance floors, car interiors, and bride entries for genuine raw emotion.
              </p>
              <div className="pt-2 text-xs text-zinc-300 font-mono">
                ✓ DJI Motorized Gimbal · Rode Wireless Mics
              </div>
            </div>

            <div className="p-6 rounded-2xl border border-zinc-800 bg-zinc-900/50 space-y-3">
              <div className="h-10 w-10 rounded-xl bg-amber-400/10 border border-amber-400/20 text-amber-400 flex items-center justify-center font-bold">
                03
              </div>
              <h3 className="text-base font-bold text-white">Instant Same-Day AirDrop &amp; 24h Edits</h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Don’t wait weeks. Get all raw clips AirDropped before you leave the venue, plus fully graded, beat-synced edited reels ready to post the next morning.
              </p>
              <div className="pt-2 text-xs text-zinc-300 font-mono">
                ✓ AirDrop All B-Roll · 24h Master Reel
              </div>
            </div>
          </div>

        </div>
      </section>

    </div>
  );
};
