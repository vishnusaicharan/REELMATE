import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, 
  Calendar, 
  Clock, 
  MapPin, 
  Phone, 
  User, 
  Instagram, 
  Music, 
  CheckCircle2, 
  Copy, 
  Check, 
  QrCode, 
  ExternalLink, 
  Upload, 
  FileText,
  AlertCircle
} from 'lucide-react';
import { formatCurrency, generateUpiQrDataUrl } from '../utils/qrHelper';
import confetti from 'canvas-confetti';
import { Booking } from '../types';

export const BookingModal: React.FC = () => {
  const { 
    isBookingModalOpen, 
    closeBookingModal, 
    selectedCategoryForBooking, 
    selectedPackageForBooking, 
    paymentSettings,
    addBooking 
  } = useApp();

  // Form states
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);
  const [eventDate, setEventDate] = useState<string>('');
  const [startTime, setStartTime] = useState<string>('16:00');
  const [durationHours, setDurationHours] = useState<number>(3);
  
  // Client details
  const [clientName, setClientName] = useState<string>('');
  const [clientPhone, setClientPhone] = useState<string>('');
  const [clientEmail, setClientEmail] = useState<string>('');
  const [instagramHandle, setInstagramHandle] = useState<string>('');
  const [venueLocation, setVenueLocation] = useState<string>('');
  const [musicAestheticVibe, setMusicAestheticVibe] = useState<string>('Cinematic Slow-mo & Emotional Acoustic');
  const [specialInstructions, setSpecialInstructions] = useState<string>('');
  
  // Payment states
  const [paymentMode, setPaymentMode] = useState<'ADVANCE' | 'FULL'>('ADVANCE');
  const [transactionId, setTransactionId] = useState<string>('');
  const [paymentReceiptUrl, setPaymentReceiptUrl] = useState<string>('');
  const [copiedUpi, setCopiedUpi] = useState(false);
  const [dynamicQrUrl, setDynamicQrUrl] = useState<string>('');
  const [confirmedBooking, setConfirmedBooking] = useState<Booking | null>(null);
  const [errorMsg, setErrorMsg] = useState<string>('');

  // Default event date to tomorrow
  useEffect(() => {
    if (isBookingModalOpen) {
      setStep(1);
      setErrorMsg('');
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      setEventDate(tomorrow.toISOString().split('T')[0]);
      if (selectedPackageForBooking) {
        setDurationHours(selectedPackageForBooking.durationHours);
      }
    }
  }, [isBookingModalOpen, selectedPackageForBooking]);

  // Pricing calculations
  const totalPrice = selectedPackageForBooking?.price || 0;
  const advancePercentage = paymentSettings.advancePercentage || 30;
  const advanceAmount = Math.round((totalPrice * advancePercentage) / 100);
  const payableAmount = paymentMode === 'ADVANCE' ? advanceAmount : totalPrice;

  // Generate dynamic QR code when payable amount changes
  useEffect(() => {
    if (paymentSettings.qrCodeType === 'dynamic' && payableAmount > 0) {
      generateUpiQrDataUrl(
        paymentSettings.upiId,
        paymentSettings.payeeName,
        payableAmount,
        `Reel Creator Deposit - ${selectedPackageForBooking?.name || 'Booking'}`
      ).then(url => setDynamicQrUrl(url));
    }
  }, [paymentSettings, payableAmount, selectedPackageForBooking]);

  if (!isBookingModalOpen || !selectedCategoryForBooking || !selectedPackageForBooking) {
    return null;
  }

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(paymentSettings.upiId);
    setCopiedUpi(true);
    setTimeout(() => setCopiedUpi(false), 2000);
  };

  const handleReceiptUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPaymentReceiptUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleNextToClientDetails = (e: React.FormEvent) => {
    e.preventDefault();
    if (!eventDate) {
      setErrorMsg('Please select a valid event date.');
      return;
    }
    setErrorMsg('');
    setStep(2);
  };

  const handleNextToPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!clientName.trim() || !clientPhone.trim() || !venueLocation.trim()) {
      setErrorMsg('Please enter your name, contact phone, and event venue location.');
      return;
    }
    setErrorMsg('');
    setStep(3);
  };

  const handleFinalSubmitBooking = (e: React.FormEvent) => {
    e.preventDefault();
    if (!transactionId.trim()) {
      setErrorMsg('Please enter the 12-digit UPI Reference Number / UTR or Transaction ID.');
      return;
    }

    const newBooking = addBooking({
      categoryId: selectedCategoryForBooking.id,
      categoryName: selectedCategoryForBooking.name,
      packageId: selectedPackageForBooking.id,
      packageName: selectedPackageForBooking.name,
      eventDate,
      startTime,
      durationHours,
      clientName: clientName.trim(),
      clientPhone: clientPhone.trim(),
      clientEmail: clientEmail.trim(),
      instagramHandle: instagramHandle.trim(),
      venueLocation: venueLocation.trim(),
      musicAestheticVibe,
      specialInstructions: specialInstructions.trim(),
      totalPrice,
      advancePaid: payableAmount,
      paymentMode,
      transactionId: transactionId.trim(),
      paymentReceiptUrl: paymentReceiptUrl || undefined,
    });

    setConfirmedBooking(newBooking);
    setStep(4);

    // Fire celebratory confetti!
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 }
    });
  };

  // Generate UPI payment intent link for mobile clicks
  const upiDeepLink = `upi://pay?pa=${encodeURIComponent(paymentSettings.upiId)}&pn=${encodeURIComponent(paymentSettings.payeeName)}&am=${payableAmount.toFixed(2)}&cu=INR&tn=${encodeURIComponent(`ReelBooking-${selectedPackageForBooking.name}`)}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-zinc-900 border border-zinc-800 rounded-2xl shadow-2xl overflow-hidden my-8">
        
        {/* Modal Top Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800 bg-zinc-950/60">
          <div>
            <div className="flex items-center gap-2 text-xs text-amber-400 font-semibold uppercase tracking-wider">
              <span>{selectedCategoryForBooking.name}</span>
              <span aria-hidden="true">·</span>
              <span>{selectedPackageForBooking.name}</span>
            </div>
            <h3 className="text-lg font-bold text-white">
              {step === 1 && 'Step 1: Pick Date & Time Slot'}
              {step === 2 && 'Step 2: Event & Client Details'}
              {step === 3 && 'Step 3: Pay via QR or UPI ID'}
              {step === 4 && 'Booking Slip & Confirmation'}
            </h3>
          </div>
          <button
            onClick={closeBookingModal}
            className="p-1.5 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800 transition-colors cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Stepper indicator */}
        {step < 4 && (
          <div className="px-6 pt-3 pb-2 bg-zinc-950/30 border-b border-zinc-800/60 flex items-center justify-between text-xs font-medium">
            <span className={step >= 1 ? 'text-amber-400 font-bold' : 'text-zinc-500'}>1. Date &amp; Time</span>
            <span className="text-zinc-700">→</span>
            <span className={step >= 2 ? 'text-amber-400 font-bold' : 'text-zinc-500'}>2. Venue &amp; Info</span>
            <span className="text-zinc-700">→</span>
            <span className={step >= 3 ? 'text-amber-400 font-bold' : 'text-zinc-500'}>3. Payment (QR/UPI)</span>
          </div>
        )}

        {/* Error message */}
        {errorMsg && (
          <div className="mx-6 mt-4 p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 text-xs flex items-center gap-2">
            <AlertCircle className="h-4 w-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* STEP 1: Date & Time Picker */}
        {step === 1 && (
          <form onSubmit={handleNextToClientDetails} className="p-6 space-y-6">
            <div className="rounded-xl border border-zinc-800 bg-zinc-950/40 p-4 flex items-center justify-between text-xs">
              <div>
                <p className="text-zinc-400">Selected Package</p>
                <p className="text-base font-bold text-white mt-0.5">{selectedPackageForBooking.name}</p>
                <p className="text-zinc-500 mt-1">
                  {selectedPackageForBooking.reelsCount} Edited Reels · {selectedPackageForBooking.turnaroundHours}h Delivery
                </p>
              </div>
              <div className="text-right">
                <p className="text-xs text-zinc-400">Total Price</p>
                <p className="text-xl font-black text-amber-400 tabular-nums">
                  {formatCurrency(totalPrice, paymentSettings.currencySymbol)}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                  Event Shoot Date *
                </label>
                <div className="relative">
                  <input
                    type="date"
                    required
                    value={eventDate}
                    onChange={(e) => setEventDate(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-400"
                  />
                  <Calendar className="absolute right-3.5 top-3 h-4 w-4 text-zinc-500 pointer-events-none" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                  Creator Arrival Time *
                </label>
                <div className="relative">
                  <input
                    type="time"
                    required
                    value={startTime}
                    onChange={(e) => setStartTime(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-400"
                  />
                  <Clock className="absolute right-3.5 top-3 h-4 w-4 text-zinc-500 pointer-events-none" />
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                Expected Shoot Duration (Hours)
              </label>
              <div className="grid grid-cols-4 gap-2">
                {[2, 3, 5, 8].map((hours) => (
                  <button
                    key={hours}
                    type="button"
                    onClick={() => setDurationHours(hours)}
                    className={`py-2 px-3 text-xs font-semibold rounded-lg border transition-all cursor-pointer ${
                      durationHours === hours
                        ? 'bg-amber-400 text-zinc-950 border-amber-400 font-bold'
                        : 'bg-zinc-950 text-zinc-300 border-zinc-800 hover:border-zinc-700'
                    }`}
                  >
                    {hours} Hours
                  </button>
                ))}
              </div>
              <p className="text-[11px] text-zinc-500 mt-2">
                Standard package includes {selectedPackageForBooking.durationHours} hours. Overtime is billed at creator hourly rate.
              </p>
            </div>

            <div className="flex justify-end gap-3 pt-4 border-t border-zinc-800">
              <button
                type="button"
                onClick={closeBookingModal}
                className="px-4 py-2.5 text-xs font-medium text-zinc-400 hover:text-white transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 text-xs font-bold text-zinc-950 bg-amber-400 rounded-xl hover:bg-amber-300 transition-all cursor-pointer"
              >
                Continue to Event Details
              </button>
            </div>
          </form>
        )}

        {/* STEP 2: Client & Event Information */}
        {step === 2 && (
          <form onSubmit={handleNextToPayment} className="p-6 space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                  Your Full Name *
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    placeholder="e.g. Rahul Sharma"
                    value={clientName}
                    onChange={(e) => setClientName(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-400 pl-9"
                  />
                  <User className="absolute left-3 top-3 h-4 w-4 text-zinc-500" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                  WhatsApp / Phone Number *
                </label>
                <div className="relative">
                  <input
                    type="tel"
                    required
                    placeholder="+91 98765 43210"
                    value={clientPhone}
                    onChange={(e) => setClientPhone(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-400 pl-9"
                  />
                  <Phone className="absolute left-3 top-3 h-4 w-4 text-zinc-500" />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                  Instagram Handle (for tags &amp; collabs)
                </label>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="@yourhandle"
                    value={instagramHandle}
                    onChange={(e) => setInstagramHandle(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-400 pl-9"
                  />
                  <Instagram className="absolute left-3 top-3 h-4 w-4 text-zinc-500" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                  Email Address (for HD Drive Delivery)
                </label>
                <input
                  type="email"
                  placeholder="name@example.com"
                  value={clientEmail}
                  onChange={(e) => setClientEmail(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                Event Venue / Showroom Address *
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  placeholder="e.g. Taj West End, Race Course Road OR Porsche Center, Lavelle Road"
                  value={venueLocation}
                  onChange={(e) => setVenueLocation(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-400 pl-9"
                />
                <MapPin className="absolute left-3 top-3 h-4 w-4 text-zinc-500" />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                Desired Reel Music &amp; Aesthetic Vibe
              </label>
              <div className="relative">
                <select
                  value={musicAestheticVibe}
                  onChange={(e) => setMusicAestheticVibe(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-400 pl-9 cursor-pointer"
                >
                  <option value="Cinematic Slow-mo & Emotional Acoustic">Cinematic Slow-mo &amp; Emotional Acoustic</option>
                  <option value="High-Octane Engine Revs & Speed-ramping (Automotive)">High-Octane Engine Revs &amp; Speed-ramping (Automotive)</option>
                  <option value="Trending Bollywood Dance & Haldi Beats">Trending Bollywood Dance &amp; Haldi Beats</option>
                  <option value="Modern Club / EDM Bass-drop Hype">Modern Club / EDM Bass-drop Hype</option>
                  <option value="Vintage Leica Film Grain & Minimalist Warmth">Vintage Film Grain &amp; Minimalist Warmth</option>
                </select>
                <Music className="absolute left-3 top-3 h-4 w-4 text-zinc-500" />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                Special Instructions / Moments to Prioritize
              </label>
              <textarea
                rows={2}
                placeholder="e.g. Unveil drop at 11:30 AM, capture grandmother's reaction, groom entry fireworks..."
                value={specialInstructions}
                onChange={(e) => setSpecialInstructions(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-400"
              />
            </div>

            <div className="flex justify-between items-center pt-4 border-t border-zinc-800">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="px-4 py-2.5 text-xs font-medium text-zinc-400 hover:text-white transition-colors cursor-pointer"
              >
                Back to Date
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 text-xs font-bold text-zinc-950 bg-amber-400 rounded-xl hover:bg-amber-300 transition-all cursor-pointer"
              >
                Proceed to Payment
              </button>
            </div>
          </form>
        )}

        {/* STEP 3: Payment via QR & UPI ID */}
        {step === 3 && (
          <form onSubmit={handleFinalSubmitBooking} className="p-6 space-y-6">
            
            {/* Amount Selection Toggle */}
            <div className="p-4 rounded-xl bg-zinc-950 border border-zinc-800">
              <div className="text-xs text-zinc-400 mb-2">Choose Payment Option:</div>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setPaymentMode('ADVANCE')}
                  className={`p-3 rounded-lg border text-left transition-all cursor-pointer ${
                    paymentMode === 'ADVANCE'
                      ? 'border-amber-400 bg-amber-400/10 text-white'
                      : 'border-zinc-800 bg-zinc-900/50 text-zinc-400 hover:border-zinc-700'
                  }`}
                >
                  <div className="text-xs font-bold text-amber-400">{advancePercentage}% Advance Deposit</div>
                  <div className="text-lg font-black text-white mt-1 tabular-nums">
                    {formatCurrency(advanceAmount, paymentSettings.currencySymbol)}
                  </div>
                  <div className="text-[11px] text-zinc-500 mt-0.5">Locks creator on schedule</div>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMode('FULL')}
                  className={`p-3 rounded-lg border text-left transition-all cursor-pointer ${
                    paymentMode === 'FULL'
                      ? 'border-amber-400 bg-amber-400/10 text-white'
                      : 'border-zinc-800 bg-zinc-900/50 text-zinc-400 hover:border-zinc-700'
                  }`}
                >
                  <div className="text-xs font-bold text-zinc-300">100% Full Payment</div>
                  <div className="text-lg font-black text-white mt-1 tabular-nums">
                    {formatCurrency(totalPrice, paymentSettings.currencySymbol)}
                  </div>
                  <div className="text-[11px] text-zinc-500 mt-0.5">Zero hassle on shoot day</div>
                </button>
              </div>
            </div>

            {/* QR Code and UPI ID Presentation */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
              
              {/* QR Display Card */}
              <div className="flex flex-col items-center justify-center p-5 rounded-2xl bg-white text-zinc-950 text-center shadow-lg">
                <div className="text-xs font-bold uppercase tracking-wider text-zinc-600 mb-2 flex items-center gap-1.5">
                  <QrCode className="h-4 w-4 text-zinc-900" />
                  <span>Scan to Pay with Any UPI App</span>
                </div>

                <div className="w-48 h-48 rounded-xl overflow-hidden border border-zinc-200 bg-white p-2 flex items-center justify-center">
                  {paymentSettings.qrCodeType === 'custom_image' && paymentSettings.customQrImageUrl ? (
                    <img
                      src={paymentSettings.customQrImageUrl}
                      alt="Admin Uploaded UPI QR Code"
                      className="w-full h-full object-contain"
                    />
                  ) : dynamicQrUrl ? (
                    <img
                      src={dynamicQrUrl}
                      alt="Dynamic UPI QR Code"
                      className="w-full h-full object-contain"
                    />
                  ) : (
                    <div className="text-xs text-zinc-400">Generating QR...</div>
                  )}
                </div>

                <div className="mt-2 text-xs font-bold text-zinc-900">
                  Payable: {formatCurrency(payableAmount, paymentSettings.currencySymbol)}
                </div>
                <div className="text-[11px] text-zinc-500">
                  Payee: {paymentSettings.payeeName}
                </div>
              </div>

              {/* UPI ID & App Link Details */}
              <div className="space-y-4">
                <div>
                  <label className="block text-xs text-zinc-400 mb-1">
                    Official Admin UPI ID:
                  </label>
                  <div className="flex items-center gap-2 p-2.5 rounded-xl bg-zinc-950 border border-zinc-800">
                    <span className="font-mono text-xs sm:text-sm font-bold text-amber-400 select-all truncate flex-1">
                      {paymentSettings.upiId}
                    </span>
                    <button
                      type="button"
                      onClick={handleCopyUpi}
                      className="px-2.5 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs text-zinc-200 flex items-center gap-1 cursor-pointer transition-colors shrink-0"
                    >
                      {copiedUpi ? (
                        <>
                          <Check className="h-3 w-3 text-emerald-400" />
                          <span className="text-emerald-400 font-bold">Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="h-3 w-3" />
                          <span>Copy</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-zinc-950/60 border border-zinc-800 text-xs text-zinc-400 space-y-1">
                  <p className="text-zinc-300 font-semibold">Payment Instruction:</p>
                  <p>{paymentSettings.paymentNote}</p>
                </div>

                {/* Direct mobile UPI intent link */}
                <a
                  href={upiDeepLink}
                  className="flex items-center justify-center gap-2 w-full py-2.5 px-4 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-zinc-200 border border-zinc-700/80 transition-colors"
                >
                  <ExternalLink className="h-3.5 w-3.5 text-amber-400" />
                  <span>Tap to Pay directly in GPay / PhonePe / Paytm</span>
                </a>
              </div>
            </div>

            {/* Transaction Verification Fields */}
            <div className="space-y-3 pt-4 border-t border-zinc-800">
              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1">
                  12-Digit UPI Reference Number / UTR / Transaction ID *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. 428190348210 or UPI-HDFC-XXXX"
                  value={transactionId}
                  onChange={(e) => setTransactionId(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-sm font-mono text-white focus:outline-none focus:border-amber-400"
                />
                <p className="text-[11px] text-zinc-500 mt-1">
                  Found on your GPay/PhonePe payment receipt screen after successful transfer.
                </p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1">
                  Upload Payment Screenshot Receipt (Optional)
                </label>
                <div className="flex items-center gap-3">
                  <label className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-zinc-300 hover:border-zinc-700 cursor-pointer transition-colors">
                    <Upload className="h-4 w-4 text-amber-400" />
                    <span>Choose Screenshot Image</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleReceiptUpload}
                      className="hidden"
                    />
                  </label>
                  {paymentReceiptUrl && (
                    <span className="text-xs text-emerald-400 flex items-center gap-1">
                      <CheckCircle2 className="h-3.5 w-3.5" />
                      Receipt Attached
                    </span>
                  )}
                </div>
              </div>
            </div>

            <div className="flex justify-between items-center pt-4 border-t border-zinc-800">
              <button
                type="button"
                onClick={() => setStep(2)}
                className="px-4 py-2.5 text-xs font-medium text-zinc-400 hover:text-white transition-colors cursor-pointer"
              >
                Back to Details
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 text-xs font-bold text-zinc-950 bg-gradient-to-r from-amber-400 to-yellow-300 rounded-xl hover:brightness-110 transition-all cursor-pointer shadow-md shadow-amber-500/20"
              >
                Submit Payment &amp; Lock Creator Date
              </button>
            </div>
          </form>
        )}

        {/* STEP 4: Confirmation & Digital Receipt */}
        {step === 4 && confirmedBooking && (
          <div className="p-6 space-y-6">
            <div className="text-center space-y-2">
              <div className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 mb-1">
                <CheckCircle2 className="h-7 w-7" />
              </div>
              <h4 className="text-xl font-extrabold text-white">
                Booking Received &amp; Date Reserved!
              </h4>
              <p className="text-xs text-zinc-400 max-w-md mx-auto">
                Your shoot slot is locked. The admin will verify your UTR reference within 30 minutes. You will also receive shoot coordination updates on WhatsApp.
              </p>
            </div>

            {/* Printable / Viewable Receipt Slip */}
            <div className="rounded-2xl border border-zinc-800 bg-zinc-950 p-5 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-zinc-800 text-xs">
                <div>
                  <span className="text-zinc-500">Booking Reference ID:</span>
                  <p className="font-mono font-bold text-amber-400 text-base">{confirmedBooking.id}</p>
                </div>
                <div className="text-right">
                  <span className="text-zinc-500">Verification Status:</span>
                  <p className="font-semibold text-amber-400">Pending Admin Verification</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 text-xs">
                <div>
                  <span className="text-zinc-500">Client Name:</span>
                  <p className="font-semibold text-white mt-0.5">{confirmedBooking.clientName}</p>
                </div>
                <div>
                  <span className="text-zinc-500">WhatsApp Phone:</span>
                  <p className="font-semibold text-white mt-0.5">{confirmedBooking.clientPhone}</p>
                </div>
                <div>
                  <span className="text-zinc-500">Shoot Date &amp; Time:</span>
                  <p className="font-semibold text-white mt-0.5">
                    {confirmedBooking.eventDate} at {confirmedBooking.startTime} ({confirmedBooking.durationHours} hrs)
                  </p>
                </div>
                <div>
                  <span className="text-zinc-500">Venue Location:</span>
                  <p className="font-semibold text-white mt-0.5 truncate">{confirmedBooking.venueLocation}</p>
                </div>
                <div>
                  <span className="text-zinc-500">Package &amp; Event:</span>
                  <p className="font-semibold text-white mt-0.5">{confirmedBooking.packageName}</p>
                </div>
                <div>
                  <span className="text-zinc-500">Payment Submitted:</span>
                  <p className="font-semibold text-emerald-400 mt-0.5">
                    {formatCurrency(confirmedBooking.advancePaid, paymentSettings.currencySymbol)} ({confirmedBooking.paymentMode})
                  </p>
                </div>
                <div className="col-span-2">
                  <span className="text-zinc-500">Submitted UTR / Transaction ID:</span>
                  <p className="font-mono text-zinc-300 mt-0.5">{confirmedBooking.transactionId}</p>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="flex flex-col sm:flex-row items-center gap-3">
              <a
                href={`https://wa.me/${paymentSettings.supportPhone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(`Hi Reelmate! I just booked my iPhone reel creator for ${confirmedBooking.eventDate}. My Booking ID is ${confirmedBooking.id}. UTR: ${confirmedBooking.transactionId}`)}`}
                target="_blank"
                rel="noreferrer"
                className="w-full sm:flex-1 py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <span>Notify Creator on WhatsApp</span>
              </a>

              <button
                type="button"
                onClick={closeBookingModal}
                className="w-full sm:w-auto py-3 px-6 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-semibold transition-colors cursor-pointer"
              >
                Done &amp; Close
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
