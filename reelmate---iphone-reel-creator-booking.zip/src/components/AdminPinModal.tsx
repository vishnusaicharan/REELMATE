import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { X, Lock, KeyRound, ShieldAlert, CheckCircle2 } from 'lucide-react';

export const AdminPinModal: React.FC = () => {
  const { 
    isAdminPinModalOpen, 
    closeAdminPinModal, 
    verifyAdminPin, 
    paymentSettings 
  } = useApp();

  const [pinInput, setPinInput] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  if (!isAdminPinModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pinInput.trim()) return;

    const success = verifyAdminPin(pinInput);
    if (!success) {
      setErrorMsg('Incorrect Security PIN. Please try again.');
      setPinInput('');
    } else {
      setErrorMsg('');
      setPinInput('');
    }
  };

  const currentPin = paymentSettings.adminPin || '2026';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <div className="relative w-full max-w-sm bg-zinc-900 border border-zinc-800 rounded-2xl shadow-2xl overflow-hidden p-6 text-center space-y-5 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Close Button */}
        <button
          onClick={closeAdminPinModal}
          className="absolute top-4 right-4 p-1.5 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800 transition-colors cursor-pointer"
        >
          <X className="h-4 w-4" />
        </button>

        {/* Shield Icon */}
        <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400">
          <Lock className="h-6 w-6" />
        </div>

        <div>
          <h3 className="text-base font-bold text-white">Admin Authentication</h3>
          <p className="text-xs text-zinc-400 mt-1">
            Enter your secret master PIN to unlock prices, custom tabs, QR codes, and bookings.
          </p>
        </div>

        {errorMsg && (
          <div className="p-2.5 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 text-xs flex items-center justify-center gap-1.5">
            <ShieldAlert className="h-4 w-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="relative">
            <input
              type="password"
              autoFocus
              placeholder="Enter PIN"
              value={pinInput}
              onChange={(e) => {
                setPinInput(e.target.value);
                if (errorMsg) setErrorMsg('');
              }}
              className="w-full text-center tracking-[0.3em] font-mono text-lg font-bold py-2.5 px-4 rounded-xl bg-zinc-950 border border-zinc-800 text-white focus:outline-none focus:border-amber-400 placeholder:tracking-normal placeholder:font-sans placeholder:text-xs placeholder:text-zinc-600"
            />
            <KeyRound className="absolute left-3.5 top-3 h-4 w-4 text-zinc-500" />
          </div>

          <button
            type="submit"
            className="w-full py-2.5 px-4 rounded-xl bg-amber-400 hover:bg-amber-300 text-zinc-950 text-xs font-bold transition-all shadow-md shadow-amber-500/10 cursor-pointer"
          >
            Unlock Admin Portal
          </button>
        </form>

        {/* Quick Hint / Default PIN Helper */}
        <div className="pt-3 border-t border-zinc-800/80 text-[11px] text-zinc-500 space-y-2">
          <div className="flex items-center justify-between bg-zinc-950/60 p-2 rounded-lg border border-zinc-800/60">
            <span>Default Master PIN:</span>
            <button
              type="button"
              onClick={() => {
                setPinInput(currentPin);
                verifyAdminPin(currentPin);
              }}
              className="font-mono font-bold text-amber-400 hover:underline cursor-pointer flex items-center gap-1"
            >
              <span>{currentPin}</span>
              <span className="text-[10px] text-zinc-400">(Click to enter)</span>
            </button>
          </div>
          <p className="text-[10px] text-zinc-500">
            Tip: Press <kbd className="px-1 py-0.5 rounded bg-zinc-800 text-zinc-300 font-mono">Ctrl+Shift+A</kbd> anytime to open this prompt.
          </p>
        </div>

      </div>
    </div>
  );
};
