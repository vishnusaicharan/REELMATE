import React from 'react';
import { useApp } from '../context/AppContext';
import { ShieldCheck, Search, Film, Sparkles } from 'lucide-react';

interface HeaderProps {
  onScrollToBook?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onScrollToBook }) => {
  const { 
    openAdminModal, 
    openLookupModal, 
    openCreatorModal,
    bookings, 
    isAdminAuthenticated, 
    paymentSettings 
  } = useApp();

  const pendingCount = bookings.filter(b => b.paymentStatus === 'PENDING_VERIFICATION').length;

  return (
    <header className="sticky top-0 z-40 w-full border-b border-zinc-800/80 bg-zinc-950/90 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 sm:gap-8 px-4 sm:px-6 lg:px-8">
        {/* Zone 1: Brand Wordmark */}
        <a href="#" className="flex items-center gap-2.5 text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0 hover:text-amber-400 transition-colors">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-tr from-amber-500 to-yellow-300 text-zinc-950 font-black shadow-sm shadow-amber-500/20">
            <Film className="h-4 w-4" />
          </span>
          <span className="font-extrabold tracking-tight">Reelmate</span>
        </a>

        {/* Zone 2: Clean single-line nav links */}
        <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-zinc-400">
          <a href="#categories" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
            Event Packages
          </a>
          <a href="#showcase" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
            Reel Showcase
          </a>
          <a href="#quality" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
            Creator Gear
          </a>
          <button
            onClick={openLookupModal}
            className="flex items-center gap-1.5 hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Search className="h-3.5 w-3.5 text-zinc-500" />
            <span>Track Booking</span>
          </button>
        </nav>

        {/* Zone 3: Primary Action Area with Become a Creator & Book Reel Creator */}
        <div className="flex items-center gap-2.5 sm:gap-3 shrink-0">
          <button
            onClick={openLookupModal}
            className="lg:hidden p-2 text-zinc-400 hover:text-white transition-colors"
            title="Track Booking"
          >
            <Search className="h-4 w-4" />
          </button>

          {/* Admin Button: Only visible if authenticated OR if not hidden from public */}
          {(isAdminAuthenticated || !paymentSettings.hideAdminButtonFromPublic) && (
            <button
              onClick={() => openAdminModal()}
              className={`relative flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                isAdminAuthenticated
                  ? 'bg-amber-400/15 border border-amber-500/50 text-amber-300 hover:bg-amber-400/25'
                  : 'text-zinc-300 bg-zinc-900 border border-zinc-700/80 hover:border-amber-500/60 hover:text-white'
              }`}
            >
              <ShieldCheck className="h-3.5 w-3.5 text-amber-400" />
              <span>{isAdminAuthenticated ? 'Admin Portal' : 'Admin'}</span>
              {pendingCount > 0 && (
                <span className="flex h-4 w-4 items-center justify-center rounded-full bg-amber-500 text-[10px] font-bold text-zinc-950">
                  {pendingCount}
                </span>
              )}
            </button>
          )}

          {/* Become a Creator Button (Beside Book Reel Creator) */}
          <button
            onClick={openCreatorModal}
            className="flex items-center gap-1.5 px-3 sm:px-3.5 py-1.5 sm:py-2 text-xs font-semibold text-zinc-200 bg-zinc-900 border border-zinc-700/80 rounded-lg hover:border-amber-400/70 hover:text-white hover:bg-zinc-850 active:scale-95 transition-all whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Sparkles className="h-3.5 w-3.5 text-amber-400" />
            <span>Become a Creator</span>
          </button>

          {/* Book Reel Creator Button */}
          <button
            onClick={onScrollToBook}
            className="px-3.5 sm:px-4 py-1.5 sm:py-2 text-xs font-bold text-zinc-950 bg-gradient-to-r from-amber-400 to-yellow-300 rounded-lg hover:brightness-110 active:scale-95 transition-all shadow-sm shadow-amber-500/20 whitespace-nowrap shrink-0 cursor-pointer"
          >
            Book Reel Creator
          </button>
        </div>
      </div>
    </header>
  );
};
