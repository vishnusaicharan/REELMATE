import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, 
  Smartphone, 
  Camera, 
  Mic, 
  Upload, 
  CheckCircle2, 
  Instagram, 
  MapPin, 
  User, 
  Phone, 
  Mail, 
  Sparkles,
  Sliders,
  DollarSign,
  AlertCircle,
  Plus,
  Trash2,
  Check
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { CreatorApplication } from '../types';

const COMMON_IPHONES = [
  'iPhone 16 Pro Max',
  'iPhone 16 Pro',
  'iPhone 16 Plus',
  'iPhone 16',
  'iPhone 15 Pro Max',
  'iPhone 15 Pro',
  'iPhone 15 Plus',
  'iPhone 15',
  'iPhone 14 Pro Max',
  'iPhone 14 Pro',
  'iPhone 13 Pro Max',
];

export const BecomeCreatorModal: React.FC = () => {
  const { 
    isCreatorModalOpen, 
    closeCreatorModal, 
    addCreatorApplication, 
    paymentSettings 
  } = useApp();

  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [errorMsg, setErrorMsg] = useState('');

  // Step 1: Personal & Profile
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [city, setCity] = useState('');
  const [instagramHandle, setInstagramHandle] = useState('');
  const [portfolioUrl, setPortfolioUrl] = useState('');
  const [eventExperience, setEventExperience] = useState<string[]>([
    'Marriage & Haldi Events',
    'Car & Bike Delivery'
  ]);

  // Step 2: Phone & Gear Details ("they will upload which phone they have all")
  const [phoneModel, setPhoneModel] = useState('iPhone 16 Pro Max');
  const [phoneStorage, setPhoneStorage] = useState('512GB');
  const [secondaryPhone, setSecondaryPhone] = useState('');
  const [allPhonesList, setAllPhonesList] = useState<string[]>(['iPhone 16 Pro Max']);
  const [customPhoneInput, setCustomPhoneInput] = useState('');
  const [shootsProResLog, setShootsProResLog] = useState(true);
  const [gimbalModel, setGimbalModel] = useState('DJI Osmo Mobile 6');
  const [micModel, setMicModel] = useState('Rode Wireless PRO');
  const [lightingAndAccessories, setLightingAndAccessories] = useState('Pocket RGB Light, Magnetic Variable ND Filter');
  
  // Uploads
  const [phonePhotoUrl, setPhonePhotoUrl] = useState('');
  const [gearPhotoUrl, setGearPhotoUrl] = useState('');

  const [expectedRatePerShoot, setExpectedRatePerShoot] = useState(5000);
  const [yearsOfExperience, setYearsOfExperience] = useState('2+ years mobile videography');
  const [bioNotes, setBioNotes] = useState('');

  // Result state
  const [submittedApp, setSubmittedApp] = useState<CreatorApplication | null>(null);

  if (!isCreatorModalOpen) return null;

  const handlePhonePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhonePhotoUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleGearPhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setGearPhotoUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const togglePhoneSelection = (model: string) => {
    setAllPhonesList(prev => {
      if (prev.includes(model)) {
        if (prev.length === 1) return prev; // keep at least 1
        return prev.filter(p => p !== model);
      } else {
        return [...prev, model];
      }
    });
  };

  const addCustomPhone = () => {
    if (customPhoneInput.trim() && !allPhonesList.includes(customPhoneInput.trim())) {
      setAllPhonesList(prev => [...prev, customPhoneInput.trim()]);
      setCustomPhoneInput('');
    }
  };

  const toggleExperience = (category: string) => {
    setEventExperience(prev => 
      prev.includes(category) 
        ? prev.filter(c => c !== category)
        : [...prev, category]
    );
  };

  const handleNextToGear = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim() || !phone.trim() || !city.trim() || !instagramHandle.trim()) {
      setErrorMsg('Please enter your full name, phone number, city, and Instagram handle.');
      return;
    }
    setErrorMsg('');
    setStep(2);
  };

  const handleFinalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phoneModel.trim()) {
      setErrorMsg('Please specify which primary iPhone model you shoot with.');
      return;
    }

    const application = addCreatorApplication({
      fullName: fullName.trim(),
      phone: phone.trim(),
      email: email.trim(),
      city: city.trim(),
      instagramHandle: instagramHandle.trim(),
      portfolioUrl: portfolioUrl.trim() || undefined,
      phoneModel: phoneModel.trim(),
      phoneStorage,
      secondaryPhone: secondaryPhone.trim() || undefined,
      allPhonesList,
      shootsProResLog,
      gimbalModel: gimbalModel.trim(),
      micModel: micModel.trim(),
      lightingAndAccessories: lightingAndAccessories.trim(),
      phonePhotoUrl: phonePhotoUrl || undefined,
      gearPhotoUrl: gearPhotoUrl || undefined,
      eventExperience,
      expectedRatePerShoot: Number(expectedRatePerShoot) || 5000,
      yearsOfExperience,
      bioNotes: bioNotes.trim() || undefined,
    });

    setSubmittedApp(application);
    setStep(3);

    // Fire celebratory confetti!
    confetti({
      particleCount: 70,
      spread: 60,
      origin: { y: 0.6 }
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-zinc-900 border border-zinc-800 rounded-2xl shadow-2xl overflow-hidden my-8">
        
        {/* Top Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800 bg-zinc-950/70">
          <div>
            <div className="flex items-center gap-2 text-xs text-amber-400 font-semibold uppercase tracking-wider">
              <Camera className="h-3.5 w-3.5" />
              <span>Reelmate Creator Network</span>
            </div>
            <h3 className="text-lg font-bold text-white">
              {step === 1 && 'Step 1: Your Profile & Location'}
              {step === 2 && 'Step 2: Upload Phone & Gear Rig Specifications'}
              {step === 3 && 'Creator Application Received!'}
            </h3>
          </div>
          <button
            onClick={closeCreatorModal}
            className="p-1.5 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800 transition-colors cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Stepper tracker */}
        {step < 3 && (
          <div className="px-6 py-2.5 bg-zinc-950/40 border-b border-zinc-800 flex items-center justify-between text-xs font-medium">
            <span className={step >= 1 ? 'text-amber-400 font-bold' : 'text-zinc-500'}>
              1. Basic Profile
            </span>
            <span className="text-zinc-700">→</span>
            <span className={step >= 2 ? 'text-amber-400 font-bold' : 'text-zinc-500'}>
              2. Phone Models &amp; Camera Rig
            </span>
            <span className="text-zinc-700">→</span>
            <span className="text-zinc-500">3. Verification</span>
          </div>
        )}

        {errorMsg && (
          <div className="mx-6 mt-4 p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 text-xs flex items-center gap-2">
            <AlertCircle className="h-4 w-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* STEP 1: Basic Information */}
        {step === 1 && (
          <form onSubmit={handleNextToGear} className="p-6 space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                  Full Name *
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    placeholder="e.g. Arjun Verma"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-400 pl-9"
                  />
                  <User className="absolute left-3 top-3 h-4 w-4 text-zinc-500" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                  WhatsApp Contact Phone *
                </label>
                <div className="relative">
                  <input
                    type="tel"
                    required
                    placeholder="+91 98765 43210"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-400 pl-9"
                  />
                  <Phone className="absolute left-3 top-3 h-4 w-4 text-zinc-500" />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                  City &amp; Area You Shoot In *
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    placeholder="e.g. Bengaluru (Indiranagar / Koramangala)"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-400 pl-9"
                  />
                  <MapPin className="absolute left-3 top-3 h-4 w-4 text-zinc-500" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                  Instagram Handle / Profile Link *
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    placeholder="@yourhandle or instagram.com/..."
                    value={instagramHandle}
                    onChange={(e) => setInstagramHandle(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-400 pl-9"
                  />
                  <Instagram className="absolute left-3 top-3 h-4 w-4 text-zinc-500" />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                  Email Address
                </label>
                <div className="relative">
                  <input
                    type="email"
                    placeholder="creator@gmail.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-400 pl-9"
                  />
                  <Mail className="absolute left-3 top-3 h-4 w-4 text-zinc-500" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                  Portfolio / Drive Sample Reels Link
                </label>
                <input
                  type="url"
                  placeholder="https://drive.google.com/..."
                  value={portfolioUrl}
                  onChange={(e) => setPortfolioUrl(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-2">
                Event Categories You Shoot:
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {[
                  'Marriage & Haldi Events',
                  'Car & Bike Delivery',
                  'Birthdays & Nightlife',
                  'Corporate / Brand Launch',
                  'Fitness & Sports Reels',
                  'Fashion & Portfolios'
                ].map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => toggleExperience(cat)}
                    className={`py-2 px-3 text-xs rounded-xl border text-left transition-all cursor-pointer ${
                      eventExperience.includes(cat)
                        ? 'bg-amber-400/10 border-amber-400 text-amber-300 font-semibold'
                        : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:border-zinc-700'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-4 border-t border-zinc-800">
              <button
                type="button"
                onClick={closeCreatorModal}
                className="px-4 py-2.5 text-xs text-zinc-400 hover:text-white cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 text-xs font-bold text-zinc-950 bg-amber-400 rounded-xl hover:bg-amber-300 transition-all cursor-pointer"
              >
                Continue to Phone &amp; Gear Details
              </button>
            </div>
          </form>
        )}

        {/* STEP 2: Phone & Equipment Rig Details */}
        {step === 2 && (
          <form onSubmit={handleFinalSubmit} className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
            <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300">
              Reelmate clients expect cinema-grade vertical 4K deliverables. Please select all the phones you have, your primary setup, and upload your device photo.
            </div>

            {/* SECTION: Which Phones Do You Have (Select all that apply) */}
            <div className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-white flex items-center gap-1.5">
                  <Smartphone className="h-4 w-4 text-amber-400" />
                  <span>Which iPhones Do You Have? (Select all that apply) *</span>
                </label>
                <span className="text-[11px] text-amber-400 font-medium">
                  {allPhonesList.length} Selected
                </span>
              </div>
              <p className="text-[11px] text-zinc-400">
                Click all models you currently own or carry for dual-angle and backup coverage:
              </p>

              <div className="flex flex-wrap gap-2 pt-1">
                {COMMON_IPHONES.map((model) => {
                  const isSelected = allPhonesList.includes(model);
                  return (
                    <button
                      key={model}
                      type="button"
                      onClick={() => togglePhoneSelection(model)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all cursor-pointer flex items-center gap-1.5 ${
                        isSelected
                          ? 'bg-amber-400/15 border-amber-400 text-amber-300 font-bold'
                          : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-zinc-200 hover:border-zinc-700'
                      }`}
                    >
                      {isSelected ? <Check className="h-3 w-3 text-amber-400" /> : <Plus className="h-3 w-3 text-zinc-600" />}
                      <span>{model}</span>
                    </button>
                  );
                })}
              </div>

              {/* Add Custom/Other phone model */}
              <div className="flex gap-2 pt-1">
                <input
                  type="text"
                  placeholder="Have another model or phone? (e.g. iPhone 13 Pro, iPhone 12 Pro Max)"
                  value={customPhoneInput}
                  onChange={(e) => setCustomPhoneInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      addCustomPhone();
                    }
                  }}
                  className="flex-1 px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-400"
                />
                <button
                  type="button"
                  onClick={addCustomPhone}
                  className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-zinc-200 cursor-pointer"
                >
                  Add Model
                </button>
              </div>

              {allPhonesList.length > 0 && (
                <div className="pt-2 border-t border-zinc-800/80 flex flex-wrap items-center gap-1.5 text-[11px] text-zinc-400">
                  <span className="font-semibold text-zinc-300">Your phone fleet:</span>
                  {allPhonesList.map((m) => (
                    <span key={m} className="px-2 py-0.5 rounded bg-zinc-850 text-amber-300 border border-zinc-700 font-mono">
                      {m}
                    </span>
                  ))}
                </div>
              )}
            </div>

            {/* Primary Phone & Storage */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-zinc-300 mb-1.5 flex items-center gap-1.5">
                  <Smartphone className="h-4 w-4 text-amber-400" />
                  <span>Your Primary Shoot iPhone *</span>
                </label>
                <select
                  value={phoneModel}
                  onChange={(e) => {
                    setPhoneModel(e.target.value);
                    if (!allPhonesList.includes(e.target.value)) {
                      setAllPhonesList(prev => [...prev, e.target.value]);
                    }
                  }}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-400 cursor-pointer"
                >
                  {allPhonesList.map((m) => (
                    <option key={m} value={m}>{m} (Primary)</option>
                  ))}
                  {COMMON_IPHONES.filter(m => !allPhonesList.includes(m)).map((m) => (
                    <option key={m} value={m}>{m}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                  Storage Capacity *
                </label>
                <select
                  value={phoneStorage}
                  onChange={(e) => setPhoneStorage(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-400 cursor-pointer"
                >
                  <option value="1TB">1 TB (ProRes Ready)</option>
                  <option value="512GB">512 GB</option>
                  <option value="256GB">256 GB</option>
                  <option value="128GB">128 GB</option>
                </select>
              </div>
            </div>

            {/* Secondary / Backup Phone */}
            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                Secondary / Backup Phone (Optional)
              </label>
              <input
                type="text"
                placeholder="e.g. iPhone 15 Pro (256GB) for second angle / b-roll backup"
                value={secondaryPhone}
                onChange={(e) => setSecondaryPhone(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-400"
              />
            </div>

            {/* Apple ProRes Log toggle */}
            <div className="p-3 rounded-xl bg-zinc-950 border border-zinc-800 flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-white">Apple ProRes 4K HDR / Log Capable</span>
                <p className="text-[11px] text-zinc-400">Do you film in native Apple Log for high dynamic range color grading?</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={shootsProResLog}
                  onChange={(e) => setShootsProResLog(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-zinc-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-zinc-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-400"></div>
              </label>
            </div>

            {/* UPLOAD: Phone Device Photo & Gear Setup Photo */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              
              {/* Phone Device Photo / Settings Proof */}
              <div className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 space-y-3">
                <label className="block text-xs font-bold text-white flex items-center gap-2">
                  <Smartphone className="h-4 w-4 text-amber-400" />
                  <span>Upload Phone Photo / Proof</span>
                </label>
                <p className="text-[11px] text-zinc-400">
                  Upload a photo of your iPhone device or About settings screenshot.
                </p>

                <div className="space-y-3">
                  <label className="flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl bg-zinc-900 border border-zinc-700 hover:border-amber-400 text-xs text-white font-semibold cursor-pointer transition-colors w-full">
                    <Upload className="h-4 w-4 text-amber-400" />
                    <span>{phonePhotoUrl ? 'Change Phone Photo' : 'Upload Phone Photo'}</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handlePhonePhotoUpload}
                      className="hidden"
                    />
                  </label>

                  {phonePhotoUrl && (
                    <div className="relative group rounded-lg overflow-hidden border border-zinc-700">
                      <img
                        src={phonePhotoUrl}
                        alt="Phone verification preview"
                        className="w-full h-28 object-cover"
                      />
                      <div className="absolute inset-0 bg-black/50 flex items-center justify-between p-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <span className="text-[11px] text-emerald-300 font-semibold flex items-center gap-1">
                          <CheckCircle2 className="h-3.5 w-3.5" />
                          Phone Photo Added
                        </span>
                        <button
                          type="button"
                          onClick={() => setPhonePhotoUrl('')}
                          className="p-1 rounded bg-red-600 text-white hover:bg-red-500"
                          title="Remove photo"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Gear Rig Setup Photo */}
              <div className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 space-y-3">
                <label className="block text-xs font-bold text-white flex items-center gap-2">
                  <Upload className="h-4 w-4 text-amber-400" />
                  <span>Upload Gear Rig Setup Photo</span>
                </label>
                <p className="text-[11px] text-zinc-400">
                  Photo of your iPhone mounted on gimbal stabilizer + wireless mic rig.
                </p>

                <div className="space-y-3">
                  <label className="flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl bg-zinc-900 border border-zinc-700 hover:border-amber-400 text-xs text-white font-semibold cursor-pointer transition-colors w-full">
                    <Upload className="h-4 w-4 text-amber-400" />
                    <span>{gearPhotoUrl ? 'Change Gear Photo' : 'Upload Gear Setup'}</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleGearPhotoUpload}
                      className="hidden"
                    />
                  </label>

                  {gearPhotoUrl && (
                    <div className="relative group rounded-lg overflow-hidden border border-zinc-700">
                      <img
                        src={gearPhotoUrl}
                        alt="Gear setup preview"
                        className="w-full h-28 object-cover"
                      />
                      <div className="absolute inset-0 bg-black/50 flex items-center justify-between p-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <span className="text-[11px] text-emerald-300 font-semibold flex items-center gap-1">
                          <CheckCircle2 className="h-3.5 w-3.5" />
                          Gear Photo Added
                        </span>
                        <button
                          type="button"
                          onClick={() => setGearPhotoUrl('')}
                          className="p-1 rounded bg-red-600 text-white hover:bg-red-500"
                          title="Remove photo"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>

            </div>

            {/* Gimbal & Wireless Mic */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1.5 flex items-center gap-1.5">
                  <Sliders className="h-4 w-4 text-amber-400" />
                  <span>Motorized Gimbal / Stabilizer</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g. DJI Osmo Mobile 6, Insta360 Flow, Hohem"
                  value={gimbalModel}
                  onChange={(e) => setGimbalModel(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1.5 flex items-center gap-1.5">
                  <Mic className="h-4 w-4 text-amber-400" />
                  <span>Wireless Audio Microphone Rig</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g. Rode Wireless PRO, DJI Mic 2, Hollyland"
                  value={micModel}
                  onChange={(e) => setMicModel(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                Lighting &amp; Extra Accessories (Filters, Lenses, Lights)
              </label>
              <input
                type="text"
                placeholder="e.g. Ulanzi RGB pocket lights, Freewell Variable ND filters, Anamorphic lens"
                value={lightingAndAccessories}
                onChange={(e) => setLightingAndAccessories(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-400"
              />
            </div>

            {/* Rates & Experience */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1.5 flex items-center gap-1.5">
                  <DollarSign className="h-4 w-4 text-amber-400" />
                  <span>Your Expected Rate Per Event (₹)</span>
                </label>
                <input
                  type="number"
                  value={expectedRatePerShoot}
                  onChange={(e) => setExpectedRatePerShoot(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-400 font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                  Years of Videography Experience
                </label>
                <input
                  type="text"
                  placeholder="e.g. 2 years freelance / 15 weddings"
                  value={yearsOfExperience}
                  onChange={(e) => setYearsOfExperience(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                Tell Us Why You Love Mobile Filmmaking
              </label>
              <textarea
                rows={2}
                placeholder="e.g. I excel at candid energy, speed-ramp sound design, and same-day delivery..."
                value={bioNotes}
                onChange={(e) => setBioNotes(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white focus:outline-none focus:border-amber-400"
              />
            </div>

            <div className="flex justify-between items-center pt-4 border-t border-zinc-800">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="px-4 py-2.5 text-xs text-zinc-400 hover:text-white cursor-pointer"
              >
                Back
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 text-xs font-bold text-zinc-950 bg-gradient-to-r from-amber-400 to-yellow-300 rounded-xl hover:brightness-110 transition-all cursor-pointer shadow-md shadow-amber-500/20"
              >
                Submit Creator Application
              </button>
            </div>
          </form>
        )}

        {/* STEP 3: Confirmation Slip */}
        {step === 3 && submittedApp && (
          <div className="p-6 space-y-6 text-center">
            <div className="inline-flex h-14 w-14 items-center justify-center rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 mb-1">
              <CheckCircle2 className="h-8 w-8" />
            </div>

            <div>
              <h4 className="text-xl font-extrabold text-white">
                Application Submitted Successfully!
              </h4>
              <p className="text-xs text-zinc-400 mt-1.5 max-w-md mx-auto">
                Welcome to Reelmate! Our creator curation team will review your {submittedApp.phoneModel} gear specifications and Instagram portfolio.
              </p>
            </div>

            {/* Application Summary Slip */}
            <div className="p-5 rounded-2xl bg-zinc-950 border border-zinc-800 text-left space-y-3 max-w-lg mx-auto text-xs">
              <div className="flex items-center justify-between pb-2 border-b border-zinc-800">
                <div>
                  <span className="text-zinc-500">Application Reference ID:</span>
                  <p className="font-mono font-bold text-amber-400 text-sm">{submittedApp.id}</p>
                </div>
                <div className="text-right">
                  <span className="text-zinc-500">Status:</span>
                  <p className="font-semibold text-amber-400">Pending Review (24h)</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <span className="text-zinc-500">Creator Name:</span>
                  <p className="font-semibold text-white mt-0.5">{submittedApp.fullName}</p>
                </div>
                <div>
                  <span className="text-zinc-500">City / Base:</span>
                  <p className="font-semibold text-white mt-0.5">{submittedApp.city}</p>
                </div>
                <div>
                  <span className="text-zinc-500">Primary Phone:</span>
                  <p className="font-semibold text-white mt-0.5">{submittedApp.phoneModel} ({submittedApp.phoneStorage})</p>
                </div>
                <div>
                  <span className="text-zinc-500">Phones Fleet:</span>
                  <p className="font-semibold text-amber-300 mt-0.5 truncate">
                    {submittedApp.allPhonesList?.join(', ') || submittedApp.phoneModel}
                  </p>
                </div>
                <div>
                  <span className="text-zinc-500">Gimbal &amp; Mic:</span>
                  <p className="font-semibold text-white mt-0.5 truncate">{submittedApp.gimbalModel} · {submittedApp.micModel}</p>
                </div>
                <div>
                  <span className="text-zinc-500">Expected Rate:</span>
                  <p className="font-semibold text-emerald-400 mt-0.5">₹{submittedApp.expectedRatePerShoot.toLocaleString('en-IN')}</p>
                </div>
              </div>

              {/* Uploaded Photos Thumbnails */}
              {(submittedApp.phonePhotoUrl || submittedApp.gearPhotoUrl) && (
                <div className="pt-2 border-t border-zinc-800/80 flex items-center gap-3">
                  {submittedApp.phonePhotoUrl && (
                    <div className="flex items-center gap-1.5 text-[11px] text-zinc-300">
                      <img
                        src={submittedApp.phonePhotoUrl}
                        alt="Phone proof"
                        className="w-8 h-8 rounded object-cover border border-zinc-700"
                      />
                      <span>Phone Photo Attached</span>
                    </div>
                  )}
                  {submittedApp.gearPhotoUrl && (
                    <div className="flex items-center gap-1.5 text-[11px] text-zinc-300">
                      <img
                        src={submittedApp.gearPhotoUrl}
                        alt="Gear proof"
                        className="w-8 h-8 rounded object-cover border border-zinc-700"
                      />
                      <span>Gear Rig Attached</span>
                    </div>
                  )}
                </div>
              )}
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
              <a
                href={`https://wa.me/${paymentSettings.supportPhone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(`Hi Reelmate! I just submitted my creator application (${submittedApp.id}) with my ${submittedApp.phoneModel}. Looking forward to joining!`)}`}
                target="_blank"
                rel="noreferrer"
                className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-colors cursor-pointer"
              >
                Notify Onboarding Team on WhatsApp
              </a>

              <button
                type="button"
                onClick={closeCreatorModal}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-semibold cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
