import { Film, QrCode, Lock, Unlock, Phone, Sparkles } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const Footer: React.FC = () => {
  const { paymentSettings, requestAdminAccess, isAdminAuthenticated, logoutAdmin, openCreatorModal } = useApp();

  return (
    <footer className="border-t border-zinc-900 bg-zinc-950 py-12 text-zinc-400 text-xs">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 pb-8 border-b border-zinc-900">
          
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-white font-bold text-base">
              <span className="flex h-6 w-6 items-center justify-center rounded bg-amber-400 text-zinc-950 text-xs font-black">
                <Film className="h-3.5 w-3.5" />
              </span>
              <span>Reelmate</span>
            </div>
            <p className="text-zinc-500 text-xs max-w-md">
              On-demand iPhone Reel Creators for Wedding Celebrations, Luxury Car &amp; Superbike Deliveries, and Special Events.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-5 text-xs text-zinc-400">
            <button
              onClick={openCreatorModal}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 text-amber-300 hover:text-amber-200 hover:border-amber-400/50 transition-colors font-semibold cursor-pointer"
            >
              <Sparkles className="h-3.5 w-3.5 text-amber-400" />
              <span>Become a Creator</span>
            </button>

            <div className="flex items-center gap-1.5">
              <Phone className="h-3.5 w-3.5 text-amber-400" />
              <span>{paymentSettings.supportPhone}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <QrCode className="h-3.5 w-3.5 text-amber-400" />
              <span>UPI: {paymentSettings.upiId}</span>
            </div>
            
            {isAdminAuthenticated ? (
              <div className="flex items-center gap-3">
                <button
                  onClick={() => requestAdminAccess()}
                  className="flex items-center gap-1 text-amber-400 hover:text-amber-300 font-semibold cursor-pointer"
                >
                  <Unlock className="h-3.5 w-3.5" />
                  <span>Admin Panel</span>
                </button>
                <button
                  onClick={logoutAdmin}
                  className="text-zinc-500 hover:text-red-400 transition-colors cursor-pointer"
                >
                  Log out
                </button>
              </div>
            ) : !paymentSettings.hideAdminButtonFromPublic ? (
              <button
                onClick={() => requestAdminAccess()}
                className="text-zinc-500 hover:text-amber-400 transition-colors cursor-pointer"
              >
                Admin Login
              </button>
            ) : null}
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-8 text-[11px] text-zinc-600">
          <div className="flex items-center gap-2">
            <p>© {new Date().getFullYear()} Reelmate Studio. All rights reserved.</p>
            {/* Discreet secret admin keyhole button (only visible as a subtle dot/lock that opens the PIN dialog) */}
            <button
              onClick={() => requestAdminAccess()}
              className="text-zinc-700 hover:text-zinc-400 transition-colors cursor-pointer p-0.5"
              title="Admin Access (Shortcut: Ctrl+Shift+A)"
            >
              <Lock className="h-3 w-3" />
            </button>
          </div>
          <div className="flex items-center gap-4">
            <span>Apple ProRes 4K HDR</span>
            <span aria-hidden="true">·</span>
            <span>GPay · PhonePe · Paytm · BHIM</span>
            <span aria-hidden="true">·</span>
            <span>24-Hour Express Delivery</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
